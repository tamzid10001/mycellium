import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import TeamSection from "@/components/TeamSection";
import PartnerLogos from "@/components/PartnerLogos";
import Button from "@/components/Button";
import {
  advisoryBoard,
  coreTeam,
  guidesAndMentors,
  managementTeam,
  principles,
  siteTags,
} from "@/lib/data";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Mycellium is a catalyst, facilitator, and innovator connecting youth, startups, and global leaders to drive climate action.",
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        title={
          <>
            ECOSYSTEM
            <br />
            <span className="text-gold">BUILDERS</span>
          </>
        }
        intro="Mycellium draws inspiration from the intricate, interconnected networks of fungi that form the foundation of thriving ecosystems."
        tags={siteTags}
        backgroundImage="/images/about/about-hero-bg.jpg"
        wave={false}
      />

      <section className="bg-burgundy pb-20 text-white sm:pb-28">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[1.3fr_1fr] lg:items-center">
            <div>
              <h2 className="font-heading text-3xl font-extrabold text-gold sm:text-4xl">
                About Mycellium
              </h2>
              <div className="mt-5 space-y-4 leading-relaxed text-white/90">
                <p>
                  We serve as a catalyst, facilitator, and innovator sparking transformative
                  ideas, connecting diverse stakeholders, and nurturing creative solutions that
                  drive meaningful climate action. From youth leaders and grassroots changemakers
                  to startups, enterprises, and policymakers, Mycellium bridges local and global
                  communities to inspire shared learning and collective progress.
                </p>
                <p>
                  Our work revolves around three key areas: Climate Education, Climate Studio, and
                  Climate Connect. Through Climate Education, we organize the bi-annual Climate
                  Innovation Challenge (CIC), engaging youth and climate startups to co-create
                  innovative responses to environmental challenges. At Climate Studio, we
                  collaborate with startups, SMEs, and government institutions to provide
                  sustainability consulting, program design, and market linkages that help scale
                  climate innovation. Through Climate Connect, we celebrate ideas, foster
                  dialogue, and build a vibrant network of forward-thinking individuals and
                  organizations committed to regenerative growth.
                </p>
                <p>
                  At Mycellium, we believe that collective action, rooted in connection and shared
                  purpose, has the power to regenerate our planet just as the mycelium network
                  revitalizes the ecosystems it supports. Together, we are growing the roots of a
                  resilient, inclusive, and sustainable future.
                </p>
              </div>
            </div>
            <div className="relative aspect-[4/5] w-full overflow-hidden rounded-2xl">
              <Image
                src="/images/about/about-group-photo.jpg"
                alt="The Mycellium team collaborating"
                fill
                className="object-cover"
                sizes="(min-width: 1024px) 420px, 100vw"
              />
            </div>
          </div>

          <div className="mt-20">
            <TeamSection title="Our Core Team" members={coreTeam} />
          </div>
          <div className="mt-20">
            <TeamSection title="Advisory Board" members={advisoryBoard} />
          </div>
          <div className="mt-20">
            <TeamSection title="Management Team" members={managementTeam} />
          </div>
          <div className="mt-20">
            <TeamSection title="Guides and Mentors" members={guidesAndMentors} />
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6 text-center sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">
            Our Principles
          </h2>
          <div className="mx-auto mt-10 grid max-w-4xl gap-8 sm:grid-cols-3">
            {principles.map((principle, i) => (
              <div key={i} className="flex flex-col items-center">
                <p className="font-heading text-4xl font-extrabold text-gold">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <p className="mt-3 text-black/80">{principle}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <PartnerLogos />

      <section className="bg-gold py-16 sm:py-20">
        <div className="mx-auto max-w-4xl px-6 text-center sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy-dark sm:text-4xl">
            Our Mission
          </h2>
          <p className="mx-auto mt-4 max-w-2xl leading-relaxed text-burgundy-dark/90">
            As a catalyst, we spark transformative ideas and inspire change. As a facilitator, we
            connect diverse stakeholders, from youths to grassroots organizations and global
            leaders, enabling shared learning and collaborative action.
          </p>
          <div className="mt-8">
            <Button href="/contact" variant="dark">
              Get in Touch
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
