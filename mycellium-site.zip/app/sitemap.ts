import type { MetadataRoute } from "next";

const baseUrl = "https://mycellium.org";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/about", "/programme", "/programme/dhaka-climate-week", "/programme/climate-voices", "/climate-educators", "/climate-connect", "/climate-studio", "/impact", "/blog", "/participate", "/contact"];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: route === "" ? 1 : 0.7,
  }));
}
