import Image from "next/image";
import { climateEducationCards, studentImpactStats } from "@/lib/data";
import MyceliumHero from "@/components/MyceliumHero";
import ClimateVoices from "@/components/ClimateVoices";
import Announcements from "@/components/Announcements";
import DhakaClimate from "@/components/DhakaClimate";
import ReadMoreLink from "@/components/ReadMoreLink";
import PartnerLogos from "@/components/PartnerLogos";
import StatCard from "@/components/StatCard";

export default function HomePage() {
  return (
    <>
      <section className="relative overflow-hidden bg-burgundy pb-0 text-white">
        <MyceliumHero />

        <div className="relative h-[320px] w-full overflow-hidden sm:h-[420px]">
          <Image
            src="/images/home/hero-iceberg.jpg"
            alt="Iceberg reflected in still Arctic water at sunset"
            fill
            priority
            className="object-cover"
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-burgundy/40 to-burgundy" />
        </div>
      </section>

      <Announcements />

      <section className="bg-burgundy py-16 text-white sm:py-24">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-gold sm:text-4xl">
            Committed and Determined
          </h2>
          <p className="mt-4 max-w-4xl leading-relaxed text-white/90">
            At Mycellium we believe in collective action, rooted in strong connections and shared
            purpose — it can regenerate the world just like mycelium revitalizes the ecosystems it
            supports. As catalyst, we spark transformative ideas and inspire change. As
            facilitator, we connect diverse stakeholders, from youth to grassroots organizations
            and global leaders, enabling shared learning and collaborative action.
          </p>

          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {climateEducationCards.map((card) => (
              <div key={card.title} className="flex flex-col overflow-hidden rounded-2xl bg-white">
                <div className="p-6">
                  <h3 className="font-heading text-xl font-bold text-burgundy">{card.title}</h3>
                  <div className="mt-3">
                    <p className="text-sm leading-relaxed text-black/70">{card.text}</p>
                    <div className="mt-4">
                      <ReadMoreLink href={card.href} label={card.title} />
                    </div>
                  </div>
                </div>
                <div className="relative mt-auto aspect-[4/5] w-full">
                  <Image
                    src={card.image}
                    alt={card.title}
                    fill
                    className="object-cover"
                    sizes="(min-width: 640px) 33vw, 100vw"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <DhakaClimate />

      <ClimateVoices />

      <section className="relative overflow-hidden bg-white py-16 sm:py-24">
        <div className="relative mx-auto max-w-6xl px-6 sm:px-8">
          <div className="pointer-events-none absolute right-8 top-1/2 hidden h-[340px] w-[340px] -translate-y-1/2 overflow-hidden rounded-full lg:block xl:h-[480px] xl:w-[480px]">
            <Image
              src="/images/impact/impact-online-class.jpg"
              alt="A Climate Week NYC 2024 session with online participants shown on the screen"
              fill
              className="object-cover object-[72%_50%]"
              sizes="480px"
            />
          </div>
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">
            Impacts on students
          </h2>
          <p className="mt-2 text-lg text-black/70">Measuring Success Through Our Achievements</p>

          <div className="mt-10 grid max-w-xl gap-5 sm:grid-cols-2">
            {studentImpactStats.map((stat) => (
              <StatCard key={stat.label} value={stat.value} label={stat.label} detail={stat.detail} />
            ))}
          </div>
        </div>
      </section>

      <PartnerLogos />
    </>
  );
}
