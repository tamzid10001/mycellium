import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import ArticleRow from "@/components/ArticleRow";
import FeaturedArticle from "@/components/FeaturedArticle";
import { articles, featuredBlogArticle, siteTags } from "@/lib/data";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Stories, press coverage, and voices from the Mycellium and Climate Innovation Challenge community.",
};

export default function BlogPage() {
  return (
    <>
      <PageHero
        title={
          <>
            AMPLIFYING
            <br />
            <span className="text-gold">CLIMATE VOICES</span>
          </>
        }
        intro="Through stories, innovation, and collaboration, we spotlight the voices shaping a resilient and regenerative future."
        tags={siteTags}
        backgroundImage="/images/blog/blog-hero-bg.jpg"
        wave={false}
      />

      <FeaturedArticle article={featuredBlogArticle} />

      <div>
        {articles
          .filter((article) => article !== featuredBlogArticle)
          .map((article, i) => (
            <ArticleRow key={article.title} article={article} index={i} />
          ))}
      </div>
    </>
  );
}
