import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, CalendarDays, MapPin } from "lucide-react";
import PageHero from "@/components/PageHero";
import { dhakaClimateWeek as dcw } from "@/lib/data";
import { programmeItems } from "@/lib/programme";

export const metadata: Metadata = {
  title: "Programme",
  description:
    "Explore Mycellium's programmes and initiatives — Dhaka Climate Week 2027, the Climate Innovation Challenge, Climate Studio, Climate Connect, and Climate Voices.",
};

const typeStyles: Record<string, string> = {
  "Priority Initiative": "bg-gold text-burgundy-dark",
  "Flagship Challenge": "bg-burgundy text-gold",
  "Consulting Programme": "bg-burgundy-light text-white",
  "Event Series": "bg-charcoal text-white",
  Voices: "bg-mist text-burgundy",
};

function Tag({ type }: { type: string }) {
  return (
    <span
      className={`inline-block rounded-full px-3 py-1 text-xs font-extrabold uppercase tracking-widest ${typeStyles[type]}`}
    >
      {type}
    </span>
  );
}

export default function ProgrammePage() {
  const [dhaka, ...rest] = programmeItems;

  return (
    <>
      <PageHero
        title={
          <>
            OUR
            <br />
            <span className="text-gold">PROGRAMME</span>
          </>
        }
        intro="Programmes, initiatives, challenges, and campaigns — the ways Mycellium turns climate ideas into real-world action. Explore each one below."
        backgroundImage="/images/dhaka/dhaka-delta-sunset.jpg"
        wave={false}
      />

      <section className="bg-white py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <p className="text-xs font-extrabold uppercase tracking-widest text-burgundy-light">Featured</p>
          <Link href={dhaka.href} className="group mt-3 block">
            <article className="grid overflow-hidden rounded-3xl bg-burgundy text-white shadow-xl transition-shadow hover:shadow-2xl lg:grid-cols-[1.1fr_1fr]">
              <div className="relative min-h-[260px] lg:min-h-full">
                <Image
                  src={dhaka.image}
                  alt=""
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="(min-width: 1024px) 640px, 100vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-burgundy/80 via-transparent to-transparent" />
                <Image
                  src="/images/dhaka/dcw-logo-white.png"
                  alt="Dhaka Climate Week"
                  width={804}
                  height={273}
                  className="absolute bottom-6 left-6 h-12 w-auto"
                />
              </div>
              <div className="p-6 sm:p-10">
                <Tag type={dhaka.type} />
                <h2 className="mt-5 font-heading text-3xl font-extrabold leading-tight sm:text-4xl">{dhaka.title}</h2>
                <p className="mt-1 font-heading text-lg font-semibold text-gold">{dcw.tagline}</p>
                <p className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold uppercase tracking-wider">
                  <span className="inline-flex items-center gap-2">
                    <CalendarDays className="h-4 w-4 text-gold" aria-hidden="true" />
                    {dcw.dates}
                  </span>
                  <span className="inline-flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gold" aria-hidden="true" />
                    {dcw.location}
                  </span>
                </p>
                <p className="mt-5 leading-relaxed text-white/90">{dhaka.summary}</p>
                <span className="mt-7 inline-flex items-center gap-1.5 rounded-full bg-gold px-6 py-3 text-sm font-semibold text-burgundy-dark transition-colors group-hover:bg-gold-dark">
                  Explore Programme
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </span>
              </div>
            </article>
          </Link>
        </div>
      </section>

      <section className="bg-mist py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">More Programmes</h2>
          <p className="mt-3 max-w-2xl text-charcoal/80">
            Challenges, consulting, events, and stories — every way Mycellium works with youth, startups, and partners.
          </p>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {rest.map((item, i) => (
              <Link
                key={item.slug}
                href={item.href}
                target={item.external ? "_blank" : undefined}
                rel={item.external ? "noopener noreferrer" : undefined}
                className={`group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm transition-shadow hover:shadow-xl sm:flex-row ${
                  i === 0 ? "md:col-span-2" : ""
                }`}
              >
                <div className={`relative aspect-[16/10] sm:aspect-auto sm:w-2/5 ${i === 0 ? "sm:w-1/2" : ""}`}>
                  <Image
                    src={item.image}
                    alt=""
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(min-width: 768px) 400px, 100vw"
                  />
                </div>
                <div className="flex flex-1 flex-col p-6 sm:p-7">
                  <Tag type={item.type} />
                  <h3 className="mt-3 font-heading text-xl font-extrabold text-burgundy sm:text-2xl">{item.title}</h3>
                  <p className="mt-2 flex-1 text-sm leading-relaxed text-charcoal/80">{item.summary}</p>
                  {item.stat && (
                    <p className="mt-3 text-xs font-semibold uppercase tracking-wider text-burgundy-light">
                      {item.stat.value} · {item.stat.label}
                    </p>
                  )}
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 group-hover:decoration-burgundy">
                    {item.external ? "Explore Programme" : "Read More"}
                    {item.external ? (
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <ArrowRight className="h-4 w-4" aria-hidden="true" />
                    )}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
