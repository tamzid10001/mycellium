import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowDown, ArrowLeft, ArrowUpRight, CalendarDays, MapPin } from "lucide-react";
import DhakaProgramme from "@/components/DhakaProgramme";
import DhakaClimate from "@/components/DhakaClimate";
import Button from "@/components/Button";
import { dhakaClimateWeek as dcw } from "@/lib/data";

export const metadata: Metadata = {
  title: "Dhaka Climate Week 2027",
  description:
    "Dhaka Climate Week 2027: Bangladesh's first city-wide climate platform, 17–21 January 2027 — the full programme, themes, and partnership news.",
};

export default function DhakaClimateWeekPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-burgundy py-14 text-white sm:py-20">
        <Image
          src="/images/dhaka/dhaka-delta-sunset.jpg"
          alt="Aerial view of the river delta in Dhaka at sunset"
          fill
          priority
          className="object-cover opacity-30"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-burgundy via-burgundy/85 to-burgundy/70" />
        <div className="relative mx-auto max-w-6xl px-6 sm:px-8">
          <Link
            href="/programme"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-white/80 underline decoration-white/40 underline-offset-4 hover:decoration-white"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All Programmes
          </Link>

          <Image
            src="/images/dhaka/dcw-logo-white.png"
            alt="Dhaka Climate Week"
            width={804}
            height={273}
            className="mt-8 h-14 w-auto sm:h-16"
          />
          <span className="mt-6 inline-block rounded-xl bg-gold px-4 py-1.5 text-xs font-extrabold uppercase leading-snug tracking-wider text-burgundy-dark">
            {dcw.eyebrow}
          </span>
          <h1 className="mt-5 font-heading text-4xl font-extrabold leading-tight sm:text-5xl">{dcw.title}</h1>
          <p className="mt-1 font-heading text-xl font-semibold text-gold">{dcw.tagline}</p>

          <p className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold uppercase tracking-wider">
            <span className="inline-flex items-center gap-2">
              <CalendarDays className="h-4 w-4 text-gold" aria-hidden="true" />
              {dcw.dates}
            </span>
            <span className="inline-flex items-center gap-2">
              <MapPin className="h-4 w-4 text-gold" aria-hidden="true" />
              {dcw.location}
            </span>
          </p>

          <p className="mt-5 max-w-3xl leading-relaxed text-white/90">{dcw.summary}</p>

          <dl className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:max-w-2xl">
            {dcw.stats.map((s) => (
              <div key={s.label} className="rounded-2xl bg-white/10 p-4 text-center">
                <dd className="font-heading text-2xl font-extrabold text-gold sm:text-3xl">{s.value}</dd>
                <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-white/80">{s.label}</p>
              </div>
            ))}
          </dl>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#programme"
              className="inline-flex items-center gap-1.5 rounded-full bg-gold px-6 py-3 text-sm font-semibold text-burgundy-dark transition-colors hover:bg-gold-dark"
            >
              See the programme
              <ArrowDown className="h-4 w-4" aria-hidden="true" />
            </a>
            {dcw.links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full border border-white/60 px-6 py-3 text-sm font-semibold transition-colors hover:bg-white/10"
              >
                {l.label}
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-14 sm:py-16">
        <div className="mx-auto max-w-4xl px-6 sm:px-8">
          <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-burgundy">
            {dcw.news.label}
          </p>
          <h2 className="mt-2 font-heading text-2xl font-bold text-burgundy sm:text-3xl">{dcw.news.title}</h2>
          <p className="mt-3 leading-relaxed text-charcoal/80">{dcw.news.text}</p>
          <a
            href={dcw.news.href}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 hover:decoration-burgundy"
          >
            Read the report on {dcw.news.source}
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </section>

      <DhakaProgramme />
      <DhakaClimate />

      <section className="bg-gold py-14 sm:py-16">
        <div className="mx-auto max-w-4xl px-6 text-center sm:px-8">
          <h2 className="font-heading text-2xl font-extrabold text-burgundy-dark sm:text-3xl">
            Want to take part in Dhaka Climate Week?
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-burgundy-dark/90">
            Propose an event, become a partner, or get updates first — tell us who you are and we will get back to you.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Button href="https://www.dhkclimateweek.org/#contact" variant="dark" external>
              Get Involved
            </Button>
            <Button href="/contact" variant="burgundy">
              Contact Mycellium
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
