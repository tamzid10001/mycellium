import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { articles, climateVoices } from "@/lib/data";

export const metadata: Metadata = {
  title: "Climate Voices",
  description:
    "Climate Voices: stories, press coverage, and interviews spotlighting the youth, alumni, and partners shaping a resilient and regenerative future.",
};

export default function ClimateVoicesPage() {
  return (
    <>
      <section className="relative overflow-hidden bg-burgundy py-14 text-white sm:py-20">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.15]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(45deg, transparent, transparent 60px, rgba(253,182,20,0.5) 60px, rgba(253,182,20,0.5) 61px), repeating-linear-gradient(-45deg, transparent, transparent 60px, rgba(253,182,20,0.5) 60px, rgba(253,182,20,0.5) 61px)",
          }}
          aria-hidden="true"
        />
        <div className="relative mx-auto max-w-6xl px-6 sm:px-8">
          <Link
            href="/programme"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-white/80 underline decoration-white/40 underline-offset-4 hover:decoration-white"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All Programmes
          </Link>
          <span className="mt-8 inline-block rounded-xl bg-gold px-4 py-1.5 text-xs font-extrabold uppercase leading-snug tracking-wider text-burgundy-dark">
            Voices
          </span>
          <h1 className="mt-5 font-heading text-4xl font-extrabold sm:text-5xl">{climateVoices.title}</h1>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-white/90">{climateVoices.intro}</p>
        </div>
      </section>

      <section className="bg-white py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {articles.map((a) => (
              <a
                key={a.title}
                href={a.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex h-full flex-col overflow-hidden rounded-3xl bg-mist shadow-sm transition-shadow hover:shadow-xl"
              >
                <div className="relative aspect-[4/3]">
                  <Image
                    src={a.image}
                    alt=""
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(min-width: 1024px) 360px, (min-width: 768px) 50vw, 100vw"
                  />
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <p className="text-xs font-semibold uppercase tracking-widest text-burgundy-light">{a.source}</p>
                  <h3 className="mt-2 font-heading text-lg font-bold leading-snug text-burgundy">{a.title}</h3>
                  <p className="mt-3 line-clamp-3 flex-1 text-sm leading-relaxed text-charcoal/80">{a.excerpt}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 group-hover:decoration-burgundy">
                    Read the story
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
