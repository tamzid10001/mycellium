import type { Metadata } from "next";
import { Montserrat } from "next/font/google";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import "./globals.css";

const montserrat = Montserrat({
  variable: "--font-montserrat",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://mycellium.org"),
  title: {
    default: "Mycellium | Catalyzing Climate Solutions",
    template: "%s | Mycellium",
  },
  description:
    "Mycellium empowers youth, startups, and partners worldwide to turn ideas into climate impact through the Climate Innovation Challenge, Climate Studio, and Climate Connect.",
  openGraph: {
    title: "Mycellium | Catalyzing Climate Solutions",
    description:
      "Mycellium empowers youth, startups, and partners worldwide to turn ideas into climate impact.",
    siteName: "Mycellium",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${montserrat.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
