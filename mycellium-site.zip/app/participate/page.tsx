import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import Button from "@/components/Button";
import { CheckCircle2 } from "lucide-react";
import { cicModelSteps, participatePrograms, siteTags } from "@/lib/data";

export const metadata: Metadata = {
  title: "Participate",
  description:
    "Join the Climate Innovation Challenge as a student or climate startup — learn about eligibility, benefits, and how to apply.",
};

export default function ParticipatePage() {
  return (
    <>
      <PageHero
        title={
          <>
            JOIN THE
            <br />
            <span className="text-gold">CHALLENGE</span>
          </>
        }
        intro="The Climate Innovation Challenge (CIC) brings together students and climate startups for ten weeks of mentorship, collaboration, and real-world impact — twice a year."
        tags={siteTags}
        wave={false}
      />

      <section className="bg-burgundy pb-20 text-white sm:pb-28">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-gold sm:text-4xl">CIC Model</h2>
          <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {cicModelSteps.map((step) => (
              <div key={step.number}>
                <p className="font-heading text-3xl font-extrabold text-gold">{step.number}</p>
                <h3 className="mt-2 font-heading text-lg font-bold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/80">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <div className="grid gap-12 lg:grid-cols-2">
            <div className="rounded-3xl bg-mist p-8 sm:p-10">
              <h2 className="font-heading text-2xl font-extrabold text-burgundy sm:text-3xl">
                {participatePrograms.students.title}
              </h2>
              <ul className="mt-6 space-y-4">
                {participatePrograms.students.benefits.map((benefit) => (
                  <li key={benefit} className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-burgundy" />
                    <span className="text-black/80">{benefit}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <Button href={participatePrograms.students.applyHref} variant="burgundy" external>
                  Apply Now
                </Button>
              </div>
            </div>

            <div className="rounded-3xl bg-burgundy p-8 text-white sm:p-10">
              <h2 className="font-heading text-2xl font-extrabold text-gold sm:text-3xl">
                {participatePrograms.startups.title}
              </h2>
              <ul className="mt-6 space-y-4">
                {participatePrograms.startups.benefits.map((benefit) => (
                  <li key={benefit} className="flex items-start gap-3">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-gold" />
                    <span className="text-white/90">{benefit}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <Button href={participatePrograms.startups.applyHref} variant="gold" external>
                  Apply Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
