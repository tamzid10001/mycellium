import type { Metadata } from "next";
import Image from "next/image";
import { ClipboardCheck, CloudSun, Coins, Cpu, Handshake, Leaf, Users, Wheat, type LucideIcon } from "lucide-react";
import PageHero from "@/components/PageHero";
import ProgramSwitcher from "@/components/ProgramSwitcher";
import ProgramExplore from "@/components/ProgramExplore";
import { studio } from "@/lib/programs";

export const metadata: Metadata = {
  title: "Climate Studio",
  description:
    "Climate Studio transforms ideas into scalable solutions — from soil health tools for farmers in Bangladesh to climate education in Australia.",
};

const p = studio.project;

const areaIcons: Record<string, LucideIcon> = {
  "Climate Adaptation": CloudSun,
  "Climate Mitigation": Leaf,
  "Agriculture & Food Chain": Wheat,
  "Agri-tech Innovation": Cpu,
  "People Centric Innovation": Users,
  "Stakeholder Connections": Handshake,
  "Impact Assessment": ClipboardCheck,
  "Direct & Indirect Investments": Coins,
};

function AreaIcon({ label, small = false }: { label: string; small?: boolean }) {
  const Icon = areaIcons[label];
  return (
    <li className="flex flex-col items-center gap-2 text-center">
      <span
        className={`flex items-center justify-center rounded-full bg-white text-burgundy ${
          small ? "h-11 w-11" : "h-14 w-14"
        }`}
      >
        <Icon className={small ? "h-5 w-5" : "h-7 w-7"} aria-hidden="true" />
      </span>
      <span className={`${small ? "text-[11px]" : "text-xs"} leading-tight text-white/90`}>{label}</span>
    </li>
  );
}

export default function ClimateStudioPage() {
  return (
    <>
      <PageHero
        title={
          <>
            {studio.hero.lineOne}
            <br />
            <span className="font-medium text-gold">{studio.hero.lineTwo}</span>
          </>
        }
        intro={studio.hero.intro}
        backgroundImage={studio.hero.image}
        wave={false}
      />
      <ProgramSwitcher current="/climate-studio" />

      <section className="relative overflow-hidden py-14 sm:py-20">
        <Image src={p.background} alt="" fill className="object-cover" sizes="100vw" />
        <div className="absolute inset-0 bg-gradient-to-b from-gold/90 via-gold/60 to-black/30" />
        <div className="relative mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-5xl">{p.title}</h2>
          <p className="mt-5 max-w-4xl leading-relaxed text-charcoal">{p.lead}</p>

          <div className="mt-10 grid gap-6 lg:grid-cols-2">
            <div className="rounded-3xl bg-burgundy p-6 text-white sm:p-8">
              <h3 className="border-b border-white/40 pb-2 font-heading text-lg font-extrabold uppercase">{p.solution.title}</h3>
              <p className="mt-3 text-sm text-white/90">{p.solution.text}</p>
              <p className="mt-6 border-b border-white/40 pb-2 text-xs font-extrabold uppercase tracking-wider">
                {p.solution.areasLabel}
              </p>
              <ul className="mt-5 grid grid-cols-3 gap-3">
                {p.solution.areas.map((a) => (
                  <AreaIcon key={a} label={a} />
                ))}
              </ul>
            </div>
            <div className="rounded-3xl bg-burgundy p-6 text-white sm:p-8">
              <h3 className="border-b border-white/40 pb-2 font-heading text-lg font-extrabold uppercase">{p.mycellium.title}</h3>
              <p className="mt-3 text-sm text-white/90">{p.mycellium.text}</p>
              <p className="mt-5 text-xs font-extrabold uppercase tracking-wider">{p.mycellium.journeyLabel}</p>
              <ol className="mt-3 flex items-center justify-between border-t border-white/40 pt-3 text-xs">
                {p.mycellium.stages.map((s, i) => (
                  <li key={s} className="flex flex-col items-center gap-1.5">
                    <span
                      aria-hidden="true"
                      className={`h-3.5 w-3.5 rounded-full ${i === p.mycellium.activeStage ? "bg-gold" : "bg-white"}`}
                    />
                    <span className={i === p.mycellium.activeStage ? "font-bold text-gold" : "text-white/80"}>{s}</span>
                  </li>
                ))}
              </ol>
              <p className="mt-6 border-b border-white/40 pb-2 text-xs font-extrabold uppercase tracking-wider">
                {p.mycellium.areasLabel}
              </p>
              <ul className="mt-5 grid grid-cols-3 gap-3 sm:grid-cols-5">
                {p.mycellium.areas.map((a) => (
                  <AreaIcon key={a} label={a} small />
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-mist py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{p.title}</h2>
          <p className="mt-5 max-w-4xl leading-relaxed text-charcoal">{p.more}</p>
          <div className="mt-10 max-w-4xl space-y-8">
            {p.impactAreas.map((a) => (
              <div key={a.title}>
                <h3 className="font-heading text-lg font-bold text-charcoal">{a.title}</h3>
                <p className="mt-2 leading-relaxed text-charcoal">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-mist pb-14 sm:pb-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <div className="max-w-4xl space-y-8 border-t border-black/10 pt-12">
            {p.support.map((s) => (
              <div key={s.title}>
                <h3 className="font-heading text-lg font-bold text-charcoal">{s.title}</h3>
                <p className="mt-2 leading-relaxed text-charcoal">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-charcoal sm:text-4xl">{p.title}</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {p.activities.map((a) => (
              <figure key={a.src} className="overflow-hidden rounded-lg bg-gold">
                <div className="relative aspect-[4/3]">
                  <Image src={a.src} alt={a.activity} fill className="object-cover" sizes="(min-width: 1024px) 360px, (min-width: 640px) 50vw, 100vw" />
                </div>
                <figcaption className="p-4 text-xs leading-relaxed text-burgundy">
                  <span className="font-bold">Activity:</span> {a.activity}
                  {a.participants && (
                    <>
                      <br />
                      <span className="font-bold">Participants:</span> {a.participants}
                    </>
                  )}
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <ProgramExplore current="/climate-studio" />
    </>
  );
}
