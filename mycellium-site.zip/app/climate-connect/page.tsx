import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import ProgramSwitcher from "@/components/ProgramSwitcher";
import ProgramExplore from "@/components/ProgramExplore";
import EventSection from "@/components/EventSection";
import { connect } from "@/lib/programs";

export const metadata: Metadata = {
  title: "Climate Connect",
  description:
    "Climate Connect brings together youth, innovators, and global partners to exchange ideas and drive collective action — from Melbourne and Sydney to Climate Week NYC, Penn, and Dhaka.",
};

export default function ClimateConnectPage() {
  return (
    <>
      <PageHero
        title={
          <>
            {connect.hero.lineOne}
            <br />
            <span className="font-medium text-gold">{connect.hero.lineTwo}</span>
          </>
        }
        intro={connect.hero.intro}
        backgroundImage={connect.hero.image}
        wave={false}
      />
      <ProgramSwitcher current="/climate-connect" />
      {connect.events.map((event) => (
        <EventSection key={event.id} event={event} />
      ))}
      <ProgramExplore current="/climate-connect" />
    </>
  );
}
