import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import ContactForm from "@/components/ContactForm";
import SocialIcons from "@/components/SocialIcons";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with Mycellium about the Climate Innovation Challenge, partnerships, or press.",
};

export default function ContactPage() {
  return (
    <>
      <PageHero
        title={
          <>
            LET&apos;S BUILD
            <br />
            <span className="text-gold">SOMETHING TOGETHER</span>
          </>
        }
        intro="Whether you're a student, a climate startup, an educator, or a potential partner — we'd love to hear from you."
        wave={false}
      />

      <section className="relative bg-burgundy pb-20 pt-4 text-white sm:pb-28">
        <div className="mx-auto max-w-3xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-gold sm:text-4xl">
            Contact Mycellium
          </h2>
          <p className="mt-3 text-white/85">
            We will get back to you after reviewing your request.
          </p>

          <div className="mt-10">
            <ContactForm />
          </div>

          <div className="mt-12 flex justify-center gap-6">
            <SocialIcons className="text-white" iconClassName="h-6 w-6" />
          </div>
        </div>
      </section>
    </>
  );
}
