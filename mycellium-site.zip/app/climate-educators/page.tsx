import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import ProgramSwitcher from "@/components/ProgramSwitcher";
import ProgramExplore from "@/components/ProgramExplore";
import Button from "@/components/Button";
import { educators as e } from "@/lib/programs";

export const metadata: Metadata = {
  title: "Climate Educators",
  description:
    "The Climate Innovation Challenge (CIC) educates and empowers students worldwide through mentorship, startup collaboration, and global exchange.",
};

const cardTones = {
  charcoal: "bg-charcoal text-white",
  amber: "bg-gold text-burgundy",
  berry: "bg-burgundy-light text-white",
  deep: "bg-burgundy text-white",
} as const;
const numberTones = {
  charcoal: "text-white",
  amber: "text-burgundy",
  berry: "text-gold",
  deep: "text-gold",
} as const;

function Benefits({ items, dark = false }: { items: string[]; dark?: boolean }) {
  return (
    <ol className="space-y-6">
      {items.map((item, i) => (
        <li key={item} className={`border-b-2 pb-4 ${dark ? "border-gold" : "border-burgundy"}`}>
          <div className="flex items-baseline gap-5">
            <span className={`font-heading text-3xl font-extrabold sm:text-4xl ${dark ? "text-gold" : "text-burgundy"}`}>
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className={`font-semibold ${dark ? "text-white" : "text-charcoal"}`}>{item}</span>
          </div>
        </li>
      ))}
    </ol>
  );
}

function ImpactCards({
  cards,
}: {
  cards: { value: string; text: string; image: string; focus?: string }[];
}) {
  return (
    <div className="mt-8 grid gap-4 sm:grid-cols-3">
      {cards.map((c) => (
        <div key={c.value} className="flex h-full flex-col overflow-hidden rounded-3xl bg-white shadow-sm">
          <div className="p-5">
            {/* Fixed-height text block: keeps the image starting at the same
                vertical position across all three cards, regardless of how
                many lines each card's description wraps to. */}
            <div className="min-h-[84px]">
              <p className="font-heading text-2xl font-extrabold text-burgundy">{c.value}</p>
              <p className="mt-1 text-sm text-black/70">{c.text}</p>
            </div>
          </div>
          <div className="relative aspect-[4/3]">
            <Image
              src={c.image}
              alt=""
              fill
              className="object-cover"
              style={c.focus ? { objectPosition: c.focus } : undefined}
              sizes="(min-width: 640px) 33vw, 100vw"
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function Banner({ banner }: { banner: { value: string; text: string; image: string } }) {
  return (
    <div className="relative mt-4 overflow-hidden rounded-3xl">
      <Image src={banner.image} alt="" fill className="object-cover" sizes="(min-width: 1152px) 1152px, 100vw" />
      <div className="absolute inset-0 bg-black/45" />
      <div className="relative p-6 text-white sm:p-10 sm:pb-16 lg:pt-14">
        <p className="font-heading text-2xl font-extrabold sm:text-3xl">{banner.value}</p>
        <p className="mt-2 max-w-2xl">{banner.text}</p>
      </div>
    </div>
  );
}

function StatsSlide({
  title,
  bg,
  stats,
}: {
  title: string;
  bg?: string;
  stats: { value: string; label: string; note?: string }[];
}) {
  const circles = ["bg-burgundy-light", "bg-gold text-burgundy-dark", "bg-burgundy", "bg-gold text-burgundy-dark"];
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-charcoal via-burgundy-dark to-burgundy py-16 text-white sm:py-24">
      {bg && (
        <>
          <Image src={bg} alt="" fill className="object-cover" sizes="100vw" />
          <div className="absolute inset-0 bg-black/55" />
        </>
      )}
      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-6 sm:px-8 lg:grid-cols-[1fr_1.6fr]">
        <h2 className="font-heading text-4xl font-extrabold sm:text-5xl">{title}</h2>
        <div className="grid grid-cols-2 gap-4 sm:gap-6">
          {stats.map((s, i) => (
            <div
              key={s.value}
              className={`flex aspect-square flex-col items-center justify-center rounded-full p-5 text-center opacity-95 ${circles[i % circles.length]}`}
            >
              <p className="font-heading text-2xl font-extrabold sm:text-4xl">{s.value}</p>
              <p className="mt-1 text-xs font-semibold sm:text-sm">{s.label}</p>
              {s.note && <p className="mt-1 text-[10px] opacity-90 sm:text-xs">{s.note}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function ClimateEducatorsPage() {
  return (
    <>
      <PageHero
        title={
          <>
            {e.hero.lineOne}
            <br />
            <span className="font-medium text-gold">{e.hero.lineTwo}</span>
          </>
        }
        intro={e.hero.intro}
        backgroundImage={e.hero.image}
        wave={false}
      />
      <ProgramSwitcher current="/climate-educators" />

      <section className="bg-mist py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.about.title}</h2>
          <div className="mt-6 max-w-4xl space-y-5 leading-relaxed text-charcoal">
            {e.about.paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-mist pb-14 sm:pb-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.model.title}</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {e.model.steps.map((s) => (
              <article
                key={s.number}
                className={`flex flex-col overflow-hidden rounded-3xl ${cardTones[s.tone as keyof typeof cardTones]}`}
              >
                <div className="relative aspect-[4/3]">
                  <Image src={s.image} alt="" fill className="object-cover" sizes="(min-width: 1024px) 280px, 50vw" />
                </div>
                <div className="p-5">
                  <p className={`font-heading text-3xl font-extrabold ${numberTones[s.tone as keyof typeof numberTones]}`}>
                    {s.number}
                  </p>
                  <h3 className="mt-2 font-heading text-sm font-bold uppercase leading-snug">{s.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed">{s.text}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.studentBenefits.title}</h2>
          <div className="mt-8 grid items-center gap-10 lg:grid-cols-[1fr_1fr]">
            <div className="relative aspect-[16/10] overflow-hidden rounded-lg border-4 border-burgundy">
              <Image src={e.studentBenefits.image} alt="Students in a CIC online session" fill className="object-cover" sizes="(min-width: 1024px) 560px, 100vw" />
            </div>
            <div>
              <Benefits items={e.studentBenefits.items} />
              <div className="mt-8">
                <Button href={e.studentBenefits.applyHref} variant="burgundy" external>
                  Apply Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-mist py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.studentImpact.title}</h2>
          <ImpactCards cards={e.studentImpact.cards} />
          <Banner banner={e.studentImpact.banner} />
        </div>
      </section>

      <StatsSlide title={e.studentImpact.statsTitle} bg={e.studentImpact.statsBg} stats={e.studentImpact.stats} />

      <section className="bg-burgundy-light py-14 text-white sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold sm:text-4xl">{e.startupBenefits.title}</h2>
          <div className="mt-8 grid items-center gap-10 lg:grid-cols-[1fr_1fr]">
            <div className="grid grid-cols-2 gap-2 rounded-lg border-4 border-gold p-2">
              <div className="relative col-span-2 aspect-[16/8]">
                <Image src={e.startupBenefits.images[0]} alt="CIC startup design phase session" fill className="object-cover" sizes="(min-width: 1024px) 560px, 100vw" />
              </div>
              {e.startupBenefits.images.slice(1).map((src) => (
                <div key={src} className="relative aspect-[16/10]">
                  <Image src={src} alt="CIC startup online session" fill className="object-cover" sizes="280px" />
                </div>
              ))}
            </div>
            <div>
              <Benefits items={e.startupBenefits.items} dark />
              <div className="mt-8">
                <Button href={e.startupBenefits.applyHref} variant="gold" external>
                  Apply Now
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-mist py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.startupImpact.title}</h2>
          <Banner banner={e.startupImpact.banner} />
          <ImpactCards cards={e.startupImpact.cards} />
        </div>
      </section>

      <StatsSlide title={e.startupImpact.statsTitle} bg={e.startupImpact.statsBg} stats={e.startupImpact.stats} />

      <section className="bg-white py-14 sm:py-20">
        <div className="mx-auto max-w-6xl px-6 sm:px-8">
          <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{e.partners.title}</h2>
          <div className="mt-8 grid grid-cols-2 divide-x divide-y divide-gray-200 border border-gray-200 sm:grid-cols-4">
            {e.partners.logos.map((l) => (
              <div key={l.name} className="flex aspect-[3/2] items-center justify-center p-6">
                <div className="relative h-full w-full">
                  <Image src={l.src} alt={l.name} fill className="object-contain" sizes="200px" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ProgramExplore current="/climate-educators" />
    </>
  );
}
