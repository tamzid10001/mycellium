import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import TheoryOfChange from "@/components/TheoryOfChange";
import ImpactBlock from "@/components/ImpactBlock";
import { siteTags, startupImpact, studentImpact } from "@/lib/data";

export const metadata: Metadata = {
  title: "Impact",
  description:
    "See how Mycellium's Climate Innovation Challenge is measurably impacting students, climate startups, and communities across the Global South and Global North.",
};

export default function ImpactPage() {
  return (
    <>
      <PageHero
        title={
          <>
            CULTIVATING
            <br />
            <span className="text-gold">ECOSYSTEMS</span>
            <br />
            FOR LASTING IMPACT
          </>
        }
        intro="We empower youth, startups, and partners worldwide to turn ideas into impact through programs like CIC, Climate Studio, and Climate Connect."
        tags={siteTags}
        backgroundImage="/images/impact/impact-hero-bg.jpg"
      />

      <TheoryOfChange />

      <section className="bg-white py-16 sm:py-24">
        <div className="mx-auto max-w-6xl space-y-20 px-6 sm:px-8">
          <ImpactBlock
            title="CIC Impact on Students"
            headline={studentImpact.headline}
            detail={studentImpact.detail}
            stats={studentImpact.stats}
            images={studentImpact.images}
          />
          <ImpactBlock
            title="CIC Impact on Climate Startups"
            headline={startupImpact.headline}
            detail={startupImpact.detail}
            stats={startupImpact.stats}
            images={startupImpact.images}
            reverse
          />
        </div>
      </section>
    </>
  );
}
