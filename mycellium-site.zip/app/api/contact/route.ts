import { NextResponse } from "next/server";

// Every submission is meant for Wahid — change this if that should ever differ.
const CONTACT_RECIPIENT = "wahid.hossain@mycellium.org";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);

  if (!body || !body.firstName || !body.lastName || !body.email) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  console.log(`Contact form submission (to be sent to ${CONTACT_RECIPIENT}):`, body);

  // Real delivery needs an email provider's API key. Once RESEND_API_KEY is set
  // (as a Vercel environment variable), this sends the message automatically —
  // no other code changes required.
  const apiKey = process.env.RESEND_API_KEY;
  if (apiKey) {
    const lines = [
      `First name: ${body.firstName}`,
      `Last name: ${body.lastName}`,
      `Email: ${body.email}`,
      body.company && `Company: ${body.company}`,
      body.position && `Position: ${body.position}`,
      body.institute && `Educational Institute: ${body.institute}`,
      body.message && `Message: ${body.message}`,
    ].filter(Boolean);

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Mycellium Website <onboarding@resend.dev>",
        to: [CONTACT_RECIPIENT],
        reply_to: body.email,
        subject: `New website enquiry from ${body.firstName} ${body.lastName}`,
        text: lines.join("\n"),
      }),
    });

    if (!res.ok) {
      console.error("Resend delivery failed:", await res.text());
      return NextResponse.json({ error: "Could not send the message." }, { status: 502 });
    }
  }

  return NextResponse.json({ ok: true });
}
