import Button from "@/components/Button";

export default function NotFound() {
  return (
    <section className="flex min-h-[60vh] flex-col items-center justify-center bg-burgundy px-6 py-24 text-center text-white">
      <p className="font-heading text-lg font-semibold tracking-[0.2em] text-gold">404</p>
      <h1 className="mt-2 font-heading text-4xl font-extrabold sm:text-5xl">Page not found</h1>
      <p className="mt-4 max-w-md text-white/80">
        The page you&apos;re looking for doesn&apos;t exist or has been moved.
      </p>
      <div className="mt-8">
        <Button href="/">Back to Home</Button>
      </div>
    </section>
  );
}
