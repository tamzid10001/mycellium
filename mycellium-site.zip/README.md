# Mycellium — Website

A ground-up, coded rebuild of the Mycellium Wix Studio site (Next.js App Router,
TypeScript, Tailwind CSS v4). No Wix runtime, no iframe — this is an independent
codebase ready to deploy on Vercel.

## Stack

- **Next.js 16** (App Router, Turbopack)
- **TypeScript**
- **Tailwind CSS v4** (theme tokens in `app/globals.css`)
- **lucide-react** for icons (brand icons like Instagram/LinkedIn are hand-drawn
  SVGs in `components/icons.tsx` since lucide dropped logo icons)

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Project structure

```
app/                  Routes (App Router)
  page.tsx            Home
  about/page.tsx
  impact/page.tsx
  blog/page.tsx
  participate/page.tsx
  contact/page.tsx
  api/contact/route.ts
components/           Reusable UI (Header, Footer, PageHero, TeamCard, ...)
lib/data.ts           All site content (team, partners, stats, articles, copy)
public/images/        Optimized local image assets, organized per page
```

Site copy, team bios, stats, and partner data all live in `lib/data.ts` —
edit that file to update content without touching component code.

## Content notes / decisions made during the rebuild

- **Fonts & palette**: Montserrat (via `next/font/google`) is used for all text, per the Mycellium Visual Guideline. Colors follow the guideline palette (Dark Berry #77003C, Amber #FDB614, Light Berry #9F1E5B, Light Gray #F2F2F2, Charcoal #232323).
- **Theory of Change**: the original is a static infographic image. It's
  rebuilt here as a responsive HTML/CSS component (`components/TheoryOfChange.tsx`)
  using the same copy, so it's legible on mobile and accessible to screen readers.
- **Blog**: the live site's Blog page is a curated list of external press
  coverage (not full first-party articles), so this rebuild mirrors that —
  `lib/data.ts` → `articles` is a data array of link-outs. If Mycellium starts
  publishing its own long-form posts, add a `slug`/`content` field and a
  `app/blog/[slug]/page.tsx` dynamic route; the data shape is ready for it.
- **Participate page**: on the live site this page exists in navigation but
  renders an empty "No available programs" Wix widget. This rebuild fills it
  with the real CIC benefits/eligibility/application content (with the
  organization's own Canva application links) sourced from the site's content
  brief, since that content clearly belongs there.
- **Contact page**: the live site has a leftover, never-edited Wix template
  section ("Add paragraph text. Click 'Edit Text'...") with a stock hiking
  photo — that's Wix placeholder filler, not real Mycellium content, so it
  was left out. The Contact page here goes straight from a proper hero into
  the real contact form.
- **Contact form**: submits to `app/api/contact/route.ts`, which validates
  and logs the submission server-side. It is **not** wired to an email
  provider yet (no credentials were available). To make it deliver email,
  add a provider (e.g. [Resend](https://resend.com) or SendGrid) inside that
  route handler — it's a single, isolated place to add the integration.
- Minor spelling issues present on the live site ("ECOSYSTEMD", "grassroot",
  "orgnizations") were corrected; wording and structure were otherwise kept
  as close to the source as possible.

## Images

All images were downloaded from the live site's own asset CDN, resized, and
re-compressed (150MB of originals → ~14MB), then organized under
`public/images/*`. Nothing hotlinks to Wix.

## Deploying to Vercel

1. Push this project to a Git repository (GitHub/GitLab/Bitbucket).
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Framework preset: Next.js (auto-detected). No environment variables are
   required for the site to build and run.
4. Deploy. Every push to the main branch will auto-deploy.

To wire up real contact-form email delivery before going live, add the
provider's API key as a Vercel environment variable and use it in
`app/api/contact/route.ts`.
