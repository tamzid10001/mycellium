import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async redirects() {
    return [{ source: "/programs", destination: "/programme", permanent: true }];
  },
};

export default nextConfig;
