export type ProgramLink = { label: string; href: string };

export const programLinks: ProgramLink[] = [
  { label: "Climate Educators", href: "/climate-educators" },
  { label: "Climate Studio", href: "/climate-studio" },
  { label: "Climate Connect", href: "/climate-connect" },
];

export type Photo = { src: string; alt: string };

/* ---------------------------------------------------------------- */
/* Climate Educators (Canva "Climate Education", slides 46–59)       */
/* ---------------------------------------------------------------- */

export const educators = {
  hero: {
    lineOne: "EDUCATING YOUTH",
    lineTwo: "INSPIRING CHANGE",
    intro:
      "Mycellium empowers students through CIC platforms, using mentorship, collaboration, and global exchange to transform ideas into real-world climate solutions that advance sustainability and social impact.",
    image: "/images/educators/hero.jpg",
  },
  about: {
    title: "Climate Innovation Challenge",
    paragraphs: [
      "The Climate Innovation Challenge (CIC) is a global virtual program that brings together students, climate start-ups, academics and policy makers in bi-annual cohorts of 60 students. Each cohort moves through an intensive 10-week consultancy with training workshops facilitated by partners like Columbia Climate School, University of Pennsylvania, and Climate Hive to develop sustainable climate solutions for real-world partners. Students are organized into teams, collaborate closely with climate start-ups (for profit as well as non-profit) for intensive ten-week consultancy projects.",
      "CIC is organized by Mycellium and supported by Columbia Climate School, Penn Environmental Innovation Initiative of University of Pennsylvania, Climate Hive, UNDP Bangladesh Accelerator Lab and the Resolution Project. Through collaboration, CIC aims to empower the next generation of leaders to address global challenges, creating a more sustainable future for all.",
    ],
  },
  model: {
    title: "CIC Model",
    steps: [
      {
        number: "01",
        title: "Immersive Climate and Innovation Workshops",
        text: "CIC offers experiential, collaborative learning through eight workshops on climate literacy, communication, and design thinking supported by partners like Columbia Climate School, UPenn, ARUP Australia, and HSBC Bangladesh to foster interdisciplinary and critical thinking.",
        image: "/images/educators/cic-1.jpg",
        tone: "charcoal",
      },
      {
        number: "02",
        title: "Collaborative Projects with Climate Startups",
        text: "Selected participants collaborate with climate start-ups, gaining hands-on experience, practical skills, and real world insights beyond academia.",
        image: "/images/educators/cic-2.jpg",
        tone: "amber",
      },
      {
        number: "03",
        title: "Tailored Mentorship and Peer Review",
        text: "Each team is assigned with a dedicated mentor, receiving critical feedback and suggestions in the process of creating collaborative solutions. Regular peer feedback sessions help create a recursive model for personal and professional growth for each participant.",
        image: "/images/educators/cic-3.jpg",
        tone: "berry",
      },
      {
        number: "04",
        title: "Engaging Students and Climate Startups Worldwide",
        text: "Held twice a year, CIC connects global youth and climate start-ups for ten weeks of collaborative learning, leadership growth, and lasting global connections.",
        image: "/images/educators/cic-4.jpg",
        tone: "deep",
      },
    ],
  },
  studentBenefits: {
    title: "Benefits for Student",
    items: [
      "Join a global climate network and connect with young people.",
      "Learn through interdisciplinary and hands-on learning.",
      "Explore passions in climate change and social innovation.",
      "Gain real-world experience with ample mentorship.",
    ],
    image: "/images/educators/benefit-students.jpg",
    applyHref:
      "https://www.canva.com/design/DAG3Jp5mAFI/AjlwOqz7H3a5m5DLckyDHw/edit?utm_content=DAG3Jp5mAFI&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton",
  },
  studentImpact: {
    title: "CIC Impact on Students",
    cards: [
      {
        value: "182 STUDENTS",
        text: "Gained interdisciplinary climate experience and climate education",
        image: "/images/educators/impact-students-1.jpg",
      },
      {
        value: "75%",
        text: "Participants representing from Global South",
        image: "/images/educators/impact-students-2.jpg",
      },
      {
        value: "53%",
        text: "Female participation driving climate gender equality",
        image: "/images/educators/impact-students-3.jpg",
      },
    ],
    banner: {
      value: "53 COUNTRIES AND 124 UNIVERSITIES",
      text: "Collaborated with 26 climate startups tackling global climate and business challenges through innovation and teamwork.",
      image: "/images/educators/impact-students-4.jpg",
    },
    statsTitle: "Impacts on students",
    stats: [
      { value: "53%", label: "female participation", note: "promoting gender equality in the climate industry" },
      {
        value: "182 students",
        label: "have gained experiential interdisciplinary climate learning",
        note: "opportunity through CIC since 2023",
      },
      { value: "53 Countries", label: "representing", note: "124 universities" },
      { value: "75%", label: "coming from Global South", note: "participants coming from Global South representing" },
    ],
    statsBg: "/images/connect/nyc2024-2.jpg",
  },
  startupBenefits: {
    title: "Benefits for Climate Startups",
    items: [
      "Gain international exposure and awareness.",
      "Engage in networking with global youth and climate organizations.",
      "Receive 320+ hrs consultation that addresses your business needs.",
    ],
    images: [
      "/images/educators/benefit-startups-1.jpg",
      "/images/educators/benefit-startups-2.jpg",
      "/images/educators/benefit-startups-3.jpg",
    ],
    applyHref:
      "https://www.canva.com/design/DAG3JqGGPOY/Rqz6S2cVIC1nKllhjlqYvg/edit?utm_content=DAG3JqGGPOY&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton",
  },
  startupImpact: {
    title: "CIC Impact on Climate Startups",
    banner: {
      value: "10 COUNTRIES AND 24 Climate Startups",
      text: "climate startups supported through Climate Innovation Challenge",
      image: "/images/educators/impact-startups-1.jpg",
    },
    cards: [
      {
        value: "8,320 Hours",
        text: "Consultation delivered through the CIC program",
        image: "/images/educators/impact-startups-2.jpg",
      },
      {
        value: "44% Startups",
        text: "from Global South includes Bangladesh, Nepal, Pakistan, Kenya and South Africa",
        image: "/images/educators/impact-startups-3.jpg",
      },
      {
        value: "56% Startups",
        text: "from Global North includes UK, New Zealand, Canada and USA",
        image: "/images/educators/impact-startups-4.jpg",
        focus: "center 32%",
      },
    ],
    statsTitle: "Impacts on climate startups",
    stats: [
      { value: "56%", label: "climate startups from Global North" },
      { value: "10", label: "countries" },
      { value: "24", label: "climate startups supported through CIC" },
    ],
    statsBg: "/images/educators/stats-startups-bg.jpg",
  },
  partners: {
    title: "Curriculum Partners",
    logos: [
      { name: "Climate Hive", src: "/images/educators/logo-climate-hive.png" },
      { name: "Columbia Climate School", src: "/images/educators/logo-columbia.png" },
      { name: "Environmental Innovations Initiative, University of Pennsylvania", src: "/images/educators/logo-penn-eii.png" },
      { name: "UNDP Bangladesh Accelerator Lab", src: "/images/educators/logo-undp.png" },
    ],
  },
};

/* ---------------------------------------------------------------- */
/* Climate Connect (Canva slides 60–84)                              */
/* ---------------------------------------------------------------- */

export type Block =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "ul"; label?: string; items: string[] }
  | { type: "a"; text: string; href: string };

export type ConnectEvent = {
  id: string;
  title: string;
  tone: "gray" | "amber" | "berry";
  fit?: "cover" | "contain";
  blocks: Block[];
  photos?: Photo[];
};

const ph = (prefix: string, n: number, alt: string): Photo[] =>
  Array.from({ length: n }, (_, i) => ({ src: `/images/connect/${prefix}-${i + 1}.jpg`, alt: `${alt} (${i + 1})` }));

export const connect = {
  hero: {
    lineOne: "ELEVATING",
    lineTwo: "COLLABORATION",
    intro:
      "Through Climate Connect, we bring together youth, innovators, and global partners to exchange ideas and drive collective action. From local gatherings to global stages, we elevate collaboration that transforms shared vision into real-world climate impact.",
    image: "/images/connect/hero.jpg",
  },
  events: [
    {
      id: "dhaka-climate-week-2027",
      title: "Dhaka Climate Week 2027",
      tone: "amber",
      blocks: [
        { type: "h", text: "From Frontline to Frontrunner — 17–21 January 2027, Dhaka, Bangladesh" },
        {
          type: "p",
          text: "Dhaka Climate Week, convened by Mycellium, is Bangladesh’s first city-wide climate platform: a 5-day collaborative platform connecting government, businesses, academia, communities, and youth to accelerate climate action and strengthen the climate ecosystem in Bangladesh and beyond. It brings together more than 120 events, more than 150 speakers, and more than 15,000 participants, and it is partner-led, with organisations hosting and co-creating sessions aligned with their areas of expertise.",
        },
        {
          type: "ul",
          label: "Five days, five themes:",
          items: [
            "Day 01 — Climate Leadership & Policy",
            "Day 02 — Youth, Innovation & Future Leaders",
            "Day 03 — Public–Private Partnerships",
            "Day 04 — Climate Finance & Green Investment",
            "Day 05 — Nature, Culture & Community",
          ],
        },
        { type: "h", text: "Media and strategic partnership with The Climate Watch" },
        {
          type: "p",
          text: "On 16 September 2026, Dhaka Climate Week and The Climate Watch signed a Memorandum of Understanding formalising a media and strategic partnership ahead of the 2027 edition. The Climate Watch will serve as the official media and strategic partner, with editorial coverage of the programme, white papers on key thematic areas, social media documentation, speaker and session profiles, and a post-event impact report. Both organisations are committed to ensuring that Bangladesh’s climate stories are told by Bangladeshis, for Bangladesh, and heard internationally.",
        },
        {
          type: "a",
          text: "Read the report on The Climate Watch",
          href: "https://theclimatewatch.com/dhaka-climate-week-climate-watch-sign-media-and-strategic-partnership-ahead-of-2027/",
        },
        { type: "a", text: "Visit dhkclimateweek.org", href: "https://www.dhkclimateweek.org/" },
      ],
    },
    {
      id: "melbourne",
      title: "Climate Connect Melbourne",
      tone: "gray",
      blocks: [
        { type: "h", text: "Building Pathways to Green Careers" },
        {
          type: "p",
          text: "Climate Connect Melbourne brought together over 50 passionate attendees from sustainability professionals and students to social workers for an evening of ideas, inspiration, and meaningful connection. Hosted at the Library at the Docklands, the event explored sustainable job opportunities in Melbourne and across Australia, with discussions on the future of green careers and the skills needed to thrive in climate-focused industries.",
        },
        {
          type: "p",
          text: "The event explored sustainable job opportunities across Melbourne and Australia, featuring insightful discussions on the future of green careers and the essential skills to succeed in the climate and sustainability sector. Through dynamic conversations, interactive panels, and meaningful networking, Climate Connect Melbourne inspired participants to envision their roles in building a more sustainable and resilient future.",
        },
        {
          type: "p",
          text: "Two thought-provoking panel discussions, featuring experts from Deloitte, Good on You, Beanstalk AgTech, and ATECH Global, provided valuable perspectives on ESG, climate consulting, and Australia’s fast-evolving climate startup ecosystem. The sessions were energetic, informative, and filled with actionable insights.",
        },
        {
          type: "p",
          text: "The evening concluded with a lively networking session and dinner, where participants exchanged ideas, forged collaborations, and strengthened their commitment to climate action. Supported by UNDP Bangladesh Accelerator Lab and the NSU Alumni Association Australia, the event truly embodied the spirit of connection and collective action for a greener future.",
        },
      ],
      photos: ph("melbourne", 6, "Climate Connect Melbourne"),
    },
    {
      id: "sydney",
      title: "Climate Connect Sydney",
      tone: "amber",
      blocks: [
        {
          type: "p",
          text: "Climate Connect Sydney: Where Climate, Social Impact & Technology Converge. On February 22nd, at the Darling Square Library in Sydney, Climate Connect Sydney brought together passionate youth leaders and innovators from Sydney, Berlin, Dhaka, and Baluchistan for a powerful exchange of ideas and action. Building on the legacy of the Climate Innovation Challenge, supported by UNDP Bangladesh, the event became a global hub for collaboration and creativity in addressing climate and social challenges.",
        },
        {
          type: "p",
          text: "Through interactive discussions, collaborative workshops, and cross-border dialogues, participants explored how technology, innovation, and community leadership can drive real-world climate solutions. The energy in the room reflected a shared belief that collective youth action can transform the future.",
        },
        {
          type: "p",
          text: "Climate Connect Sydney wasn’t just an event; it was a bridge between continents, ideas, and generations igniting a movement for a sustainable, inclusive, and climate-resilient world.",
        },
      ],
      photos: ph("sydney", 8, "Climate Connect Sydney"),
    },
    {
      id: "climate-week-nyc-2025",
      title: "Climate Week NYC 2025",
      tone: "berry",
      blocks: [
        { type: "h", text: "Beyond Doom and Gloom" },
        {
          type: "p",
          text: "Building on our continued presence at Climate Week NYC since 2024, Mycellium, together with the Climate Innovation Challenge (CIC) and Climate Hive, proudly hosted “Beyond Doom and Gloom: A Roundtable on Community-Driven Climate Solutions.”",
        },
        {
          type: "p",
          text: "This year’s session brought together grassroots leaders, entrepreneurs, CIC alumni, and global change-makers to explore one essential question — how we can move from climate anxiety to climate action. Through open dialogue and collaborative problem-solving, participants co-created ideas and solutions addressing some of the most urgent climate and social challenges of our time.",
        },
        {
          type: "p",
          text: "We extend our gratitude to TheSidebar, Seth Cochran, Climate Week NYC, and the Climate Group for their continued partnership and support. Together, we’re demonstrating that collective effort and community-led innovation can transform climate challenges into opportunities for lasting impact.",
        },
      ],
      photos: ph("nyc2025", 3, "Climate Week NYC 2025"),
    },
    {
      id: "climate-week-nyc-2024",
      title: "Climate Week NYC 2024",
      tone: "gray",
      blocks: [
        {
          type: "p",
          text: "On September 23rd, 2024, the Climate Innovation Challenge (CIC) proudly hosted its first-ever in-person event in North America as part of Climate Week NYC. The gathering brought together passionate changemakers from Kenya, South Africa, India, Poland, Germany, and beyond — all united by a shared mission to empower the next generation of climate innovators.",
        },
        {
          type: "p",
          text: "The event featured inspiring reflections from three CIC alumni — Sophie Brill, Juliann McCallum, and Laura Eugene — who shared their personal climate journeys, motivations, and the crucial role of youth leadership in advancing climate solutions.",
        },
        {
          type: "p",
          text: "We were also honored to welcome George Tsiatis from the Resolution Project, who highlighted the importance of investing in people and supporting youth-led initiatives to achieve lasting impact.",
        },
        {
          type: "p",
          text: "The session captured the spirit of CIC’s global community — collaborative, action-driven, and committed to turning climate ambition into tangible change.",
        },
      ],
      photos: ph("nyc2024", 3, "Climate Week NYC 2024"),
    },
    {
      id: "climate-week-penn-2025",
      title: "Climate Week at Penn 2025",
      tone: "berry",
      fit: "contain",
      blocks: [
        {
          type: "p",
          text: "As part of Climate Week at the University of Pennsylvania, the Climate Innovation Challenge (CIC) and Mycellium co-hosted two insightful panel discussions exploring the intersection of climate finance and youth participation in the global climate industry.",
        },
        { type: "h", text: "Panel 1: Bridging the Gap — VC Pathways for Global South Climate Innovation" },
        {
          type: "p",
          text: "The Global South holds immense potential for climate innovation, yet limited access to capital often hinders progress. This panel brought together leading venture capitalists and investors to discuss how to unlock funding pathways and scale impactful climate solutions.",
        },
        {
          type: "ul",
          label: "Speakers:",
          items: [
            "Oliver B. Libby, Co-founding Managing Partner, H/L Ventures & CityRock Venture Partners (USA)",
            "James Irungu Mwangi, Founder & CEO, Africa Climate Ventures and Climate Action Platform – Africa (CAP-A)",
            "Moderator: Kausar Khan, Mycellium | Renewable Energy Technical Advisor, C40 Cities South Africa Clean Energy Program",
          ],
        },
        { type: "h", text: "Panel 2: Next Generation Innovation — Why Young Professionals Matter to Scale Climate Solutions" },
        {
          type: "p",
          text: "This dynamic discussion spotlighted the critical role of young professionals in driving innovation and scaling climate solutions across the Global North and South. The session emphasized collaboration, creativity, and inclusive action as catalysts for sustainable impact.",
        },
        { type: "p", text: "Moderator: Wahid Hossain, Head of Partnership & Growth, Mycellium" },
        {
          type: "ul",
          label: "Speakers:",
          items: [
            "Charlie Zong, Massachusetts Institute of Technology (MIT), USA",
            "Grace Marr, Columbia University, USA",
            "Lucky Maduna, GLOBIS University, Japan",
            "Mehedi Hasan, Gazipur Agricultural University, Bangladesh",
          ],
        },
        {
          type: "p",
          text: "Both sessions highlighted the power of interdisciplinary collaboration and youth-led innovation in advancing global climate action — reinforcing CIC’s mission to connect ideas, people, and investment for a regenerative and equitable future.",
        },
      ],
      photos: ph("penn2025", 7, "Climate Week at Penn 2025 session poster"),
    },
    {
      id: "climate-week-penn-2024",
      title: "Climate Week at Penn 2024",
      tone: "gray",
      fit: "contain",
      blocks: [
        {
          type: "p",
          text: "As an official partner of Climate Week at the University of Pennsylvania, the Climate Innovation Challenge (CIC) proudly organized two interactive workshops and a thought-provoking panel discussion, engaging students, researchers, and innovators from across the globe.",
        },
        { type: "h", text: "Workshop 1: Ecosystem Services & Regenerative Leadership" },
        {
          type: "p",
          text: "Led by global experts from the University of Oxford, this immersive session guided participants through the value of biodiversity, ecosystem restoration, and the principles of regenerative leadership. Saskia van Oosterhout and Mark McCartney inspired youth to rethink leadership and act as stewards for both people and the planet.",
        },
        { type: "h", text: "Workshop 2: Interdisciplinary Innovation — Empowering Youth to Drive Global Climate Action" },
        {
          type: "p",
          text: "Co-facilitated by Sherry Xue (UPenn) and Md. Wahid Hossain (Mycellium), this workshop explored how interdisciplinary collaboration and youth-driven innovation can accelerate climate action and social impact worldwide. Through storytelling and hands-on group activities, participants shared creative solutions to global challenges.",
        },
        {
          type: "h",
          text: "Panel Discussion: Collaborating for Climate — The Power of Interdisciplinary Approaches in Climate Startup Ecosystems",
        },
        {
          type: "p",
          text: "Moderated by Sarah Sabin Khan (UNDP Bangladesh Accelerator Lab), this engaging panel brought together innovators including Aivan Kanon Khan (ECOWAVE), Josh Mastromatto (Rego), and Nafew Prodhan (Footsteps) to discuss how interdisciplinary collaboration drives innovation within the climate startup ecosystem.",
        },
        {
          type: "p",
          text: "Together, these sessions embodied CIC’s mission to empower youth, spark innovation, and build bridges between academia, entrepreneurship, and sustainability — amplifying the impact of global collaboration for a regenerative future.",
        },
      ],
      photos: ph("penn2024", 4, "Climate Week at Penn 2024 session poster"),
    },
    {
      id: "nextgen",
      title: "NEXTGEN: Empowering Youth for Climate Action in Times of Crisis",
      tone: "amber",
      blocks: [
        {
          type: "p",
          text: "Co-hosted by the Climate Innovation Challenge and Elevate Youth, NEXTGEN brought together young innovators, startups, and climate leaders at Impact Hub Dhaka to showcase youth-led climate solutions, humanitarian leadership, and collaboration for a more resilient and sustainable Bangladesh.",
        },
        {
          type: "p",
          text: "The hybrid workshop, led by Saskia Van Oosterhout from the University of Oxford, engaged participants from Bangladesh and five other countries to explore sustainable solutions for humanitarian crises. Youth-led startups like ECOWAVE, Shalbrikkho, and Ecoflow Revive shared their inspiring stories of turning challenges into opportunities for innovation and impact.",
        },
        {
          type: "p",
          text: "A panel discussion featuring UNDP Bangladesh, Footsteps, and ULAB experts emphasized the importance of connecting youth startups with key stakeholders and resources to scale their work. The event concluded with an exhibition showcasing next-generation climate technologies and networking sessions that sparked collaboration between students, entrepreneurs, and ecosystem partners.",
        },
        {
          type: "p",
          text: "NEXTGEN served as a powerful reminder that Bangladesh’s youth are not just witnesses to the climate crisis—they are leading the way toward a more resilient, equitable, and sustainable future.",
        },
      ],
      photos: ph("nextgen", 6, "NEXTGEN at Impact Hub Dhaka"),
    },
  ] as ConnectEvent[],
};

/* ---------------------------------------------------------------- */
/* Climate Studio (Canva slides 85–95)                               */
/* ---------------------------------------------------------------- */

export const studio = {
  hero: {
    lineOne: "ACCELERATING",
    lineTwo: "CLIMATE INNOVATION",
    intro:
      "At Climate Studio, we transform ideas into scalable solutions. From soil health tools for farmers in Bangladesh to climate education in Australia, we co-develop climate ventures and empower youth innovators to turn bold ambitions into measurable, lasting impact worldwide.",
    image: "/images/studio/hero.jpg",
  },
  project: {
    title: "Matir Pran",
    lead: "Matir Pran, an agri-tech innovation from Bangladesh that provides real-time soil data to help farmers choose the right crops, fertilizers, and water management strategies promoting sustainable farming and reducing chemical use.",
    more: "By mapping nationwide soil condition patterns, Matir Pran aims to uncover key factors driving soil change in the era of climate change. This data will support companies and researchers in developing better crop varieties, seeds, and fertilizers. Mycellium is supporting Matir Pran in building market linkages and expanding the innovation internationally.",
    background: "/images/studio/overview-bg.jpg",
    solution: {
      title: "Solution Basic",
      text: "Agri-tech solution guiding sustainable farming with precise soil data.",
      areasLabel: "Impact Areas",
      areas: ["Climate Adaptation", "Climate Mitigation", "Agriculture & Food Chain"],
    },
    mycellium: {
      title: "Mycellium Impacts on Matir Pran",
      text: "Empowering Matir Pran through innovation, investment, and strategic connections.",
      journeyLabel: "Help in Growth Journey",
      stages: ["IDEA", "MVP", "Revenue", "Growth"],
      activeStage: 1,
      areasLabel: "Impact of Areas",
      areas: [
        "Agri-tech Innovation",
        "People Centric Innovation",
        "Stakeholder Connections",
        "Impact Assessment",
        "Direct & Indirect Investments",
      ],
    },
    impactAreas: [
      {
        title: "Climate Adaptation",
        text: "Considering dynamic agro-climatic conditions, Matir Pran facilitates climate-smart agriculture by providing real-time soil data. This enables farmers to optimize crop selection, nutrient management, and water use, enhancing resilience to climate variability and supporting sustainable, adaptive farming systems.",
      },
      {
        title: "Climate Mitigation",
        text: "Matir Pran helps mitigate climate change by providing real-time soil and water data. It enables fertilizer companies to create climate-smart products, supports researchers in developing resilient seeds, and alerts governments to water level changes for timely, targeted interventions.",
      },
      {
        title: "Agriculture and Food Chain",
        text: "Matir Pran promotes food security and farmer well-being by improving soil health and agricultural productivity through data-driven insights. By guiding efficient crop, fertilizer, and water use, it helps farmers increase income, protect their rights, and reduce chemical exposure, ensuring safer food and healthier communities.",
      },
    ],
    support: [
      {
        title: "Agri-tech Innovation",
        text: "Mycellium collaborates closely with the Matir Pran team, providing technical and engineering support to develop a market-ready, commercial-grade device.",
      },
      {
        title: "People Centric Innovation",
        text: "Mycellium is supporting the development of a mobile app for the Matir Pran device, focusing on both technical design and a human-centered experience to ensure effective adoption by farmers and other users.",
      },
      {
        title: "Stakeholder Connections",
        text: "Mycellium is facilitating early adoption and field application of the Matir Pran device across 30 acres of farmland in Bangladesh. The team is also engaging potential partners and customers, including iDE, WEGRO, and others, to expand pilot testing and collaboration.",
      },
      {
        title: "Impact Assessment",
        text: "Mycellium is developing a climate and social impact model for Matir Pran, while also supporting the team with accounting, bookkeeping, communications, and impact assessment.",
      },
      {
        title: "Direct & Indirect Investments",
        text: "Mycellium supports Matir Pran through direct investment in technology development and legal registration. This assistance strengthens the foundation for innovation and future expansion.",
      },
    ],
    activities: [
      {
        src: "/images/studio/activity-1.jpg",
        activity: "Product testing in rice fields at the Bangladesh Agriculture Research Institute.",
        participants:
          "Abdullah Al Araf, Rahat Uddin, Sharmin Akter Shakila, Mehedi Hasan, Farzana Afrin Tisha, and Wahid Hossain.",
      },
      {
        src: "/images/studio/activity-2.jpg",
        activity: "Reviewing rice field test results and applications at the Bangladesh Agriculture Research Institute.",
        participants:
          "Abdullah Al Araf, Rahat Uddin, Sharmin Akter Shakila, Mehedi Hasan, Farzana Afrin Tisha, and Wahid Hossain.",
      },
      {
        src: "/images/studio/activity-3.jpg",
        activity: "Reviewing mobile applications of Matir Pran at the Bangladesh Agriculture Research Institute.",
      },
      {
        src: "/images/studio/activity-4.jpg",
        activity: "Strategic planning and ecosystem mapping discussion with Matir Pran team.",
        participants: "Rahat Uddin, Farzana Afrin Tisha, and Wahid Hossain.",
      },
      {
        src: "/images/studio/activity-5.jpg",
        activity: "Strategic planning and ecosystem mapping discussion with Matir Pran team.",
        participants: "Rahat Uddin, Farzana Afrin Tisha, and Wahid Hossain.",
      },
      {
        src: "/images/studio/activity-6.jpg",
        activity: "Initial device prototyping with Bangladesh Agriculture Research Institute’s chief Scientific Officer.",
        participants: "Abdullah Al Araf",
      },
      {
        src: "/images/studio/activity-7.jpg",
        activity: "Empowering grassroots farmers with knowledge of the Matir Pran device and its benefits.",
        participants: "Rahat Uddin and grassroots farmer",
      },
      {
        src: "/images/studio/activity-8.jpg",
        activity: "Grass root farmer using Matir Pran device to understand his chilli farm land condition.",
      },
      {
        src: "/images/studio/activity-9.jpg",
        activity: "Soil testing in guava fields conducted at the Bangladesh Agriculture Research Institute.",
        participants: "Abdullah Al Araf",
      },
    ],
  },
};
