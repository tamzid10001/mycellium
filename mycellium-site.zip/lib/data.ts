export type NavLink = {
  label: string;
  href: string;
  children?: { label: string; href: string }[];
};

export const navLinks: NavLink[] = [
  { label: "About Us", href: "/about" },
  { label: "Impact", href: "/impact" },
  {
    label: "Programme",
    href: "/programme",
    children: [
      { label: "Dhaka Climate Week 2027", href: "/programme/dhaka-climate-week" },
      { label: "Climate Innovation Challenge", href: "/climate-educators" },
      { label: "Climate Studio", href: "/climate-studio" },
      { label: "Climate Connect", href: "/climate-connect" },
      { label: "Climate Voices", href: "/programme/climate-voices" },
    ],
  },
  { label: "Blog", href: "/blog" },
  { label: "Contact Us", href: "/contact" },
];

export const socialLinks = {
  instagram: "https://www.instagram.com/cicforsdg/",
  linkedin: "https://www.linkedin.com/school/92835417/",
};

export const siteTags = [
  "Interdisciplinary Innovators",
  "Climate Consultants",
  "Ecosystem Builders",
  "Youth Leadership",
  "Climate Justice Advocates",
  "Climate Educator",
];

export type StatItem = {
  value: string;
  label: string;
  detail: string;
};

export const studentImpactStats: StatItem[] = [
  {
    value: "53%",
    label: "Female participation",
    detail: "Promoting gender equality in the climate industry",
  },
  {
    value: "182",
    label: "Students gained experiential interdisciplinary climate learning",
    detail: "Opportunity through CIC since 2023",
  },
  {
    value: "75%",
    label: "Coming from Global South",
    detail: "Participation coming from Global South",
  },
  {
    value: "53",
    label: "Countries represented",
    detail: "124 universities' participation in global climate workshops",
  },
];

export const climateEducationCards = [
  {
    title: "Climate Educators",
    text: "(CIC) educates and empowers students from around the world to collaborate across disciplines and cultures in designing and implementing real-world climate solutions. Through mentorship, startup collaboration, and global exchange, CIC transforms student ideas into impactful innovations that advance sustainability and social change.",
    href: "/climate-educators",
    image: "/images/home/card-climate-educators.jpg",
  },
  {
    title: "Climate Studio",
    text: "As interdisciplinary innovators and catalysts, we support climate startups from ideation to implementation, engage diverse stakeholders, and design solutions for governments, corporations, and nonprofits — fostering impactful strategies and breakthrough innovations in climate adaptation, mitigation, and education.",
    href: "/climate-studio",
    image: "/images/home/card-climate-studio.jpg",
  },
  {
    title: "Climate Connect",
    text: "We share stories, build connections, and spark collaboration through hands-on programs, signature events like Climate Connect, and global partnerships with platforms such as NYC Climate Week and Penn Climate Week.",
    href: "/climate-connect",
    image: "/images/home/card-climate-connect.jpg",
  },
];

export const partners = [
  { name: "Penn Climate, University of Pennsylvania", logo: "/images/partners/penn-climate.png" },
  { name: "Columbia Climate School", logo: "/images/partners/partner-02.png" },
  { name: "UNDP Bangladesh Accelerator Lab", logo: "/images/partners/partner-04.png" },
  { name: "Wyndham City", logo: "/images/partners/partner-05.png" },
  { name: "Resolution Project", logo: "/images/partners/partner-06.png" },
  { name: "sideBAR", logo: "/images/partners/partner-07.png" },
  { name: "Roberta Buffett Institute for Global Affairs, Northwestern", logo: "/images/partners/partner-08.png" },
  { name: "Climate Hive", logo: "/images/partners/partner-09.png" },
  { name: "Bridge for Billions", logo: "/images/partners/partner-10.png" },
  { name: "iDE", logo: "/images/partners/partner-11.png" },
  { name: "Climate Week NYC", logo: "/images/partners/partner-12.png" },
  { name: "Climatebase", logo: "/images/partners/partner-13.png" },
  { name: "Jamuna TV", logo: "/images/partners/partner-14.png" },
  { name: "The Climate Watch", logo: "/images/partners/partner-15.png" },
  { name: "Future Startup", logo: "/images/partners/partner-16.png" },
];

export type TeamMember = {
  name: string;
  role: string;
  org?: string;
  image: string;
  linkedin?: string;
  website?: string;
};

export const coreTeam: TeamMember[] = [
  {
    name: "Md Wahid Hossain",
    role: "Co-Founder & Director, Head of Partnership & Growth",
    org: "Mycellium",
    image: "/images/team/team-wahid-hossain.png",
    linkedin: "https://www.linkedin.com/in/mrtigerbow/",
  },
  {
    name: "Hong (Sherry) Xue",
    role: "Co-Founder & Director, Head of Programs & Innovation",
    org: "Mycellium",
    image: "/images/team/team-hong-xue.png",
    linkedin: "https://www.linkedin.com/in/sherry-xue/",
  },
  {
    name: "Md Mahbubul Alam",
    role: "Director, Head of Systems & Governance",
    org: "Mycellium",
    image: "/images/team/team-mahbubul-alam.png",
    linkedin: "http://www.linkedin.com/in/mahbubul-alam-29474a390",
  },
];

export const advisoryBoard: TeamMember[] = [
  {
    name: "Wenda Gumulya",
    role: "Co-Founder & Director (Mycellium)",
    org: "International Consultant",
    image: "/images/team/team-wenda-gumulya.png",
    linkedin: "https://www.linkedin.com/in/wenda-gumulya/",
    website:
      "https://www.afr.com/companies/professional-services/the-best-revenge-is-living-well-how-to-deal-with-sexism-20240226-p5f7qy",
  },
  {
    name: "Peter C Goldmark Jr.",
    role: "Former President",
    org: "Rockefeller Foundation",
    image: "/images/team/team-peter-goldmark.png",
    linkedin: "https://www.linkedin.com/in/petercgoldmark/",
    website: "https://resolutionproject.org/team/peter-c-goldmark-jr/",
  },
  {
    name: "George Deriso",
    role: "Founder & Coach",
    org: "Cosmos Partners",
    image: "/images/team/team-george-deriso.png",
    linkedin: "https://www.linkedin.com/in/gderiso/",
    website: "https://www.colorado.edu/programs/socialinnovation/george-deriso",
  },
  {
    name: "Saskia van Oosterhout",
    role: "Head Tutor, Emergency Climate Programme",
    org: "Oxford University",
    image: "/images/team/team-saskia-van-oosterhout.png",
    linkedin: "https://www.linkedin.com/in/saskiavanoosterhout/",
    website:
      "https://climateweek.provost.upenn.edu/event/ecosystems-services-regenerative-leadership",
  },
  {
    name: "Dipesh Nag",
    role: "Managing Director",
    org: "Grameen Danone",
    image: "/images/team/team-dipesh-nag.png",
    linkedin: "https://www.linkedin.com/in/dipesh-nag-7283211a/",
  },
];

export const managementTeam: TeamMember[] = [
  {
    name: "Sharmin Akter Shakila",
    role: "Research Associate",
    org: "University of Bradford",
    image: "/images/team/team-sharmin-shakila.png",
    linkedin: "https://www.linkedin.com/in/sharminaktershakila06/",
  },
  {
    name: "Mustain Karim Chowdhury",
    role: "Manager",
    org: "Impact Hub Dhaka",
    image: "/images/team/team-mustain-karim.png",
    linkedin: "https://www.linkedin.com/in/mustainkarim/",
    website: "https://www.youtube.com/watch?v=mn_P32R8DWI",
  },
  {
    name: "Mahi Ahmed Mia",
    role: "Program Support, Climate Innovation Challenge",
    org: "Mycellium",
    image: "/images/team/team-mahi-ahmed-mia.png",
    linkedin: "https://www.linkedin.com/in/mahi-ahmed-mia-072064208/",
  },
];

export const guidesAndMentors: TeamMember[] = [
  {
    name: "Naseema Elias",
    role: "Group Sustainability Manager",
    org: "Sea Harvest Group Ltd",
    image: "/images/team/team-naseema-elias.png",
    linkedin: "https://www.linkedin.com/in/naseema-elias-1b5ba034/?originalSubdomain=za",
    website: "https://www.gbcsa.org.za/news/c40-south-africa-buildings-programme/",
  },
  {
    name: "Nhlanhla Lucky Maduna",
    role: "MBA Candidate",
    org: "Globis University",
    image: "/images/team/team-lucky-maduna.png",
    linkedin: "https://www.linkedin.com/in/nhlanhla-lucky-maduna-9a59a8187/",
    website:
      "https://climateweek.provost.upenn.edu/event/youth-led-innovation-bridging-global-north-south",
  },
  {
    name: "Kausar Khan",
    role: "Renewable Energy Technical Advisor & Program Manager",
    org: "C40 Cities",
    image: "/images/team/team-kausar-khan.png",
    linkedin: "https://www.linkedin.com/in/kausar-khan-19966845/",
    website: "https://www.c40.org/our-team/kausar-khan/",
  },
  {
    name: "Orsi Palfi",
    role: "Learning Facilitator, Youth in Global Action Program",
    org: "Mycellium",
    image: "/images/team/team-orsi-palfi.png",
    linkedin: "https://www.linkedin.com/in/orsipalfi/",
    website: "https://www.orsipalfi.com/",
  },
];

export const principles = [
  "We cultivate networks that inspire shared purpose and collective action.",
  "We catalyze creative ideas into scalable climate solutions.",
  "We nurture resilient ecosystems that sustain people and the planet.",
];

export const studentImpact = {
  stats: [
    { value: "182 STUDENTS", label: "Gained interdisciplinary climate experience and climate education" },
    { value: "75%", label: "Participants representing from Global South" },
    { value: "53%", label: "Female participation driving climate gender equality" },
  ],
  headline: "53 COUNTRIES AND 124 UNIVERSITIES",
  detail:
    "Collaborated with 26 climate startups tackling global climate and business challenges through innovation and teamwork.",
  images: ["/images/impact/impact-photo-1.jpg", "/images/impact/impact-photo-2.jpg", "/images/impact/impact-photo-3.jpg"],
};

export const startupImpact = {
  headline: "10 COUNTRIES AND 24 CLIMATE STARTUPS",
  detail: "Climate startups supported through Climate Innovation Challenge",
  stats: [
    {
      value: "56% Startups",
      label: "From Global North includes UK, New Zealand, Canada and USA",
    },
    {
      value: "8,320 Hours",
      label: "Consultation delivered through the CIC program",
    },
    {
      value: "44% Startups",
      label: "From Global South includes Bangladesh, Nepal, Pakistan, Kenya and South Africa",
    },
  ],
  images: ["/images/impact/impact-photo-4.jpg", "/images/impact/impact-photo-5.jpg", "/images/impact/impact-photo-6.jpg"],
};

export type Article = {
  title: string;
  excerpt: string;
  image: string;
  href: string;
  source: string;
};

// Featured on Blog (as the prominent lead item) AND included in `articles`,
// so it also shows in Climate Voices (Programme) and the Home teaser.
export const featuredBlogArticle: Article = {
  title: "Dhaka Climate Week, Climate Watch Sign Media and Strategic Partnership Ahead of 2027",
  excerpt:
    "On 16 September 2026, Dhaka Climate Week and The Climate Watch signed a Memorandum of Understanding formalising a media and strategic partnership ahead of Dhaka Climate Week 2027. The Climate Watch becomes the official media and strategic partner, covering the programme through editorial coverage, thematic white papers, social media documentation, speaker and session profiles, and a post-event impact report.",
  image: "/images/dhaka/dhaka-delta-sunset.jpg",
  href: "https://theclimatewatch.com/dhaka-climate-week-climate-watch-sign-media-and-strategic-partnership-ahead-of-2027/",
  source: "The Climate Watch",
};

export const articles: Article[] = [
  featuredBlogArticle,
  {
    title: "NextGen Climate Leaders: Bridging Innovation and Action in Times of Crisis",
    excerpt:
      "NEXTGEN Climate Actions in Times of Crisis highlighted how CIC alumni and young innovators are supporting Bangladesh through floods, heat waves, and cyclones. Through climate technology, sustainable products, and community-driven solutions, these youth leaders are building resilience and inspiring hope for a safer future.",
    image: "/images/blog/blog-article-nextgen.jpg",
    href: "https://www.linkedin.com/pulse/nextgen-climate-leaders-bridging-innovation-c0a3c/",
    source: "LinkedIn",
  },
  {
    title: "Empowering Tomorrow's Climate Leaders",
    excerpt:
      "Climate is no longer just a problem — it's a literacy, a mindset, and a framework for decision-making across all fields. The Climate Innovation Challenge (CIC) empowers students worldwide to tackle real-world climate issues through collaboration and project-based learning. Columbia Climate School's Climate Ready CU provides adaptable resources to help partners integrate climate thinking into diverse disciplines and professional practices.",
    image: "/images/blog/blog-article-1.jpg",
    href: "https://www.linkedin.com/pulse/empowering-tomorrows-climate-leaders-climate-innovation-challenge-xnuac/",
    source: "LinkedIn",
  },
  {
    title: "Building a Unique Interdisciplinary Global Program for Climate Education and Innovation",
    excerpt:
      "Climate Innovation Challenge (CIC) is redefining climate education through a unique interdisciplinary model. This six-week virtual program unites students from 14 countries and 21 universities, including Columbia and Dhaka University, to collaborate on real-world solutions with global organizations. Co-founded by Wahid Hossain, Wenda Gumulya, and Sherry Xue, CIC fosters innovation, peer learning, and scalable impact.",
    image: "/images/blog/blog-article-2.jpg",
    href: "https://futurestartup.com/2024/04/24/climate-innovation-challenge-cic-model/",
    source: "FutureStartup",
  },
  {
    title: "What We Learned About VC Pathways for Global South Climate Innovation",
    excerpt:
      "The Global South is too often framed as a victim of climate change — dependent on aid, lacking capacity, waiting for solutions. Africa and South Asia are not charity cases. They are growth markets for climate-positive innovation. With abundant sunlight, vast renewable potential, young labor forces, and underutilized land, these regions could host some of the world's most cost-effective clean energy and sustainable industries.",
    image: "/images/blog/blog-article-3.jpg",
    href: "https://www.linkedin.com/pulse/bridging-gap-what-we-learned-vc-pathways-kvgxc/",
    source: "LinkedIn",
  },
  {
    title: "Northwestern Alumna Fosters Global Collaboration among University Students Advancing Climate Action",
    excerpt:
      "Discover how global student collaboration through the Climate Innovation Challenge is unlocking transformative climate action by young changemakers across 24 countries. This inspiring initiative, co-led by Mycellium, connects universities and youth worldwide to foster innovation, shared learning, and scalable solutions for a more resilient, sustainable planet.",
    image: "/images/blog/blog-article-4.jpg",
    href: "https://buffett.northwestern.edu/news/2024/northwestern-alumna-fosters-global-collaboration-among-university-students-advancing-climate-action.html",
    source: "Northwestern Buffett Institute",
  },
  {
    title: "Uniting Young Minds to Tackle Climate Change",
    excerpt:
      "Discover how UNDP Bangladesh's Accelerator Lab is collaborating with young minds through the Climate Innovation Challenge to tackle climate change. This inspiring initiative unites students across borders, fostering collaboration, innovation, and actionable solutions from sustainable fashion to solar-powered technologies for a more resilient and sustainable future.",
    image: "/images/blog/blog-article-5.jpg",
    href: "https://www.undp.org/bangladesh/blog/solution-find-solutions-uniting-young-minds-tackle-climate-change",
    source: "UNDP Bangladesh",
  },
];

export const contactFormFields = [
  { name: "firstName", label: "First name", required: true, placeholder: "Enter your first name" },
  { name: "lastName", label: "Last name", required: true, placeholder: "Enter your last name" },
  { name: "email", label: "Email", required: true, placeholder: "Enter your email", type: "email" },
  { name: "company", label: "Company name", required: false, placeholder: "Enter a company name" },
  { name: "position", label: "Position", required: false, placeholder: "Enter a position or job title" },
  {
    name: "institute",
    label: "Educational Institute",
    required: false,
    placeholder: "If you are a teacher or student",
  },
] as const;

export const participatePrograms = {
  students: {
    title: "Benefits for Students",
    benefits: [
      "Join a global climate network and connect with young people.",
      "Learn through interdisciplinary and hands-on learning.",
      "Explore passions in climate change and social innovation.",
      "Gain real-world experience with ample mentorship.",
    ],
    applyHref:
      "https://www.canva.com/design/DAG3Jp5mAFI/AjlwOqz7H3a5m5DLckyDHw/edit?utm_content=DAG3Jp5mAFI&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton",
  },
  startups: {
    title: "Benefits for Climate Startups",
    benefits: [
      "Gain international exposure and awareness.",
      "Engage in networking with global youth and climate organizations.",
      "Receive 320+ hours of consultation that addresses your business needs.",
    ],
    applyHref:
      "https://www.canva.com/design/DAG3JqGGPOY/Rqz6S2cVIC1nKllhjlqYvg/edit?utm_content=DAG3JqGGPOY&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton",
  },
};

export const cicModelSteps = [
  {
    number: "01",
    title: "Immersive Climate and Innovation Workshops",
    description:
      "CIC offers experiential, collaborative learning through eight workshops on climate literacy, communication, and design thinking — supported by partners like Columbia Climate School, UPenn, ARUP Australia, and HSBC Bangladesh to foster interdisciplinary and critical thinking.",
  },
  {
    number: "02",
    title: "Collaborative Projects with Climate Startups",
    description:
      "Selected participants collaborate with climate startups, gaining hands-on experience, practical skills, and real-world insights beyond academia.",
  },
  {
    number: "03",
    title: "Tailored Mentorship and Peer Review",
    description:
      "Each team is assigned a dedicated mentor, receiving critical feedback in the process of creating collaborative solutions. Regular peer feedback sessions create a recursive model for personal and professional growth.",
  },
  {
    number: "04",
    title: "Engaging Students and Climate Startups Worldwide",
    description:
      "Held twice a year, CIC connects global youth and climate startups for ten weeks of collaborative learning, leadership growth, and lasting global connections.",
  },
];

export type DhakaEvent = {
  title: string;
  summary: string;
  venue: string;
  date?: string;
  href?: string;
};

export const pastDhakaEvents: DhakaEvent[] = [
  {
    title: "NEXTGEN: Empowering Youth for Climate Action in Times of Crisis",
    summary:
      "Co-hosted by the Climate Innovation Challenge and Elevate Youth, NEXTGEN brought together young innovators, startups, and climate leaders to showcase youth-led climate solutions, humanitarian leadership, and collaboration for a more resilient and sustainable Bangladesh.",
    venue: "Impact Hub Dhaka",
    href: "https://www.linkedin.com/pulse/nextgen-climate-leaders-bridging-innovation-c0a3c/",
  },
];

export const dhakaClimateWeek = {
  eyebrow: "Priority initiative · First edition",
  title: "Dhaka Climate Week 2027",
  tagline: "From Frontline to Frontrunner",
  dates: "17 – 21 January 2027",
  location: "Dhaka, Bangladesh",
  summary:
    "A 5-day collaborative platform connecting government, businesses, academia, communities, and youth to accelerate climate action and strengthen the climate ecosystem in Bangladesh and beyond. Convened by Mycellium, it is Bangladesh’s first city-wide climate platform.",
  stats: [
    { value: "5", label: "Days" },
    { value: "120+", label: "Events" },
    { value: "15K+", label: "Participants" },
    { value: "150+", label: "Speakers" },
  ],
  programme: [
    { title: "Climate Leadership & Policy", icon: "landmark" },
    { title: "Youth, Innovation & Future Leaders", icon: "graduation" },
    { title: "Public–Private Partnerships", icon: "handshake" },
    { title: "Climate Finance & Green Investment", icon: "coins" },
    { title: "Nature, Culture & Community", icon: "tree" },
  ],
  mission:
    "Positioning Dhaka as the leading convening platform for climate resilience, adaptation and practical solutions across the Global South — the bridge where South Asia and ASEAN meet.",
  themes: [
    { label: "Urban Planning", title: "Cities Built to Last", text: "Designing Dhaka for the climate century.", icon: "building" },
    { label: "Energy Transition", title: "Roads to Zero", text: "Dhaka drives the clean mobility shift.", icon: "zap" },
    { label: "Water for Resilience", title: "Living with Water", text: "Turning the delta’s greatest threat into its strength.", icon: "droplets" },
    { label: "Tech for the Planet", title: "Intelligence for the Planet", text: "Data-driven decisions for climate survival.", icon: "cpu" },
    { label: "Agriculture", title: "Growing Through Change", text: "Climate-smart food systems from the delta.", icon: "sprout" },
    { label: "Circularity", title: "Nothing Wasted, Everything Valued", text: "Turning the city’s waste into value.", icon: "recycle" },
  ],
  lenses: [
    { name: "Local", question: "How is Dhaka innovating right now?" },
    { name: "Regional", question: "What can South Asia and ASEAN learn from each other?" },
    { name: "Global", question: "What trends, tech and policy are shaping the future?" },
    { name: "Collaboration", question: "Which partnerships and investments can scale?" },
  ],
  topics: [
    "Youth-led",
    "24 Millions",
    "Climate Frontline",
    "Digital Sustainability",
    "Smart Cities",
    "Blue Economy",
    "Clean Energy",
    "Green Mobility",
    "Climate Leadership",
  ],
  news: {
    label: "Latest news",
    title: "The Climate Watch joins as official media and strategic partner",
    text: "On 16 September 2026, Dhaka Climate Week and The Climate Watch signed a Memorandum of Understanding formalising a media and strategic partnership ahead of the 2027 edition. It covers editorial coverage of the programme, thematic white papers, social media documentation, speaker and session profiles, and a post-event impact report.",
    source: "The Climate Watch",
    href: "https://theclimatewatch.com/dhaka-climate-week-climate-watch-sign-media-and-strategic-partnership-ahead-of-2027/",
  },
  links: [
    { label: "Visit Dhaka Climate Week", href: "https://www.dhkclimateweek.org/" },
    { label: "Get involved", href: "https://www.dhkclimateweek.org/#contact" },
  ],
};

export const climateVoices = {
  title: "Climate Voices",
  intro:
    "Through stories, innovation, and collaboration, we spotlight the voices shaping a resilient and regenerative future.",
};

export const announcementPoster = {
  src: "/images/announcements/megaphone-announcement.jpg",
  alt: "Megaphone announcement graphic",
};

export const dhakaContext = {
  title: "Dhaka Climate",
  intro: [
    "Dhaka is often described through the lens of risk. Dhaka Climate Week sees something different: a city that continues to grow, adapt, and innovate despite some of the world’s most complex climate challenges.",
    "The future of climate action will not be built only in wealthy capitals. It will also be built in cities like Dhaka, where resilience is practised every day and where the Global South is shaping solutions for the world.",
  ],
  facts: [
    { value: "1,500+ km²", label: "Dhaka Metropolitan Area" },
    { value: "24 Millions", label: "People on the frontline" },
    { value: "4.25 million", label: "Youth in Dhaka" },
  ],
  photos: [
    {
      src: "/images/dhaka/dhaka-delta-sunset.jpg",
      alt: "Aerial view of the river delta in Dhaka at sunset",
    },
    {
      src: "/images/dhaka/net-positive-planning.jpg",
      alt: "A collaborative planning session with Net Positive signage and sticky notes",
    },
  ],
  nextgenPhotos: [
    { src: "/images/connect/nextgen-1.jpg", alt: "Audience at NEXTGEN at Impact Hub Dhaka" },
    { src: "/images/connect/nextgen-5.jpg", alt: "Participants at the NEXTGEN hybrid workshop in Dhaka" },
    { src: "/images/connect/nextgen-6.jpg", alt: "Young innovators and startups at NEXTGEN in Dhaka" },
  ],
};
