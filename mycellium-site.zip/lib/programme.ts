export type ProgrammeType = "Priority Initiative" | "Flagship Challenge" | "Consulting Programme" | "Event Series" | "Voices";

export type ProgrammeItem = {
  slug: string;
  type: ProgrammeType;
  title: string;
  summary: string;
  image: string;
  href: string;
  external?: boolean;
  stat?: { value: string; label: string };
};

export const programmeItems: ProgrammeItem[] = [
  {
    slug: "dhaka-climate-week",
    type: "Priority Initiative",
    title: "Dhaka Climate Week 2027",
    summary:
      "Bangladesh's first city-wide climate platform: 5 days, 120+ events, and 15,000+ people connecting government, business, academia, and youth. 17–21 January 2027.",
    image: "/images/dhaka/dhaka-delta-sunset.jpg",
    href: "/programme/dhaka-climate-week",
    stat: { value: "17–21 Jan 2027", label: "Dhaka, Bangladesh" },
  },
  {
    slug: "climate-innovation-challenge",
    type: "Flagship Challenge",
    title: "Climate Innovation Challenge (CIC)",
    summary:
      "A bi-annual, 10-week virtual programme pairing student cohorts with climate startups to design real-world sustainability solutions.",
    image: "/images/home/card-climate-educators.jpg",
    href: "/climate-educators",
    stat: { value: "182", label: "students since 2023" },
  },
  {
    slug: "climate-studio",
    type: "Consulting Programme",
    title: "Climate Studio",
    summary:
      "Hands-on consulting and investment for early-stage climate ventures, from agri-tech in Bangladesh to clean energy across the Global South.",
    image: "/images/home/card-climate-studio.jpg",
    href: "/climate-studio",
  },
  {
    slug: "climate-connect",
    type: "Event Series",
    title: "Climate Connect",
    summary:
      "A global series of gatherings — from Melbourne and Sydney to Climate Week NYC and Penn — that build connection across the climate ecosystem.",
    image: "/images/home/card-climate-connect.jpg",
    href: "/climate-connect",
  },
  {
    slug: "climate-voices",
    type: "Voices",
    title: "Climate Voices",
    summary:
      "Stories, press coverage, and interviews spotlighting the youth, alumni, and partners shaping a resilient and regenerative future.",
    image: "/images/blog/blog-article-nextgen.jpg",
    href: "/programme/climate-voices",
  },
];
