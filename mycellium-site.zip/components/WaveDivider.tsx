export default function WaveDivider({
  color = "text-white",
  flip = false,
  className = "",
}: {
  color?: string;
  flip?: boolean;
  className?: string;
}) {
  return (
    <div
      className={`pointer-events-none absolute inset-x-0 ${flip ? "top-0 rotate-180" : "bottom-0"} ${className}`}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 1440 90"
        className={`h-[50px] w-full sm:h-[80px] ${color}`}
        preserveAspectRatio="none"
        fill="currentColor"
      >
        <path d="M0,0 C360,90 1080,90 1440,0 L1440,90 L0,90 Z" />
      </svg>
    </div>
  );
}
