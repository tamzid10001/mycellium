import Link from "next/link";

export default function ReadMoreLink({ href, label }: { href: string; label: string }) {
  return (
    <Link
      href={href}
      aria-label={`Read More about ${label}`}
      className="inline-block text-sm font-semibold text-burgundy underline decoration-burgundy/50 decoration-1 underline-offset-4 transition-colors hover:decoration-burgundy focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-burgundy"
    >
      Read More
    </Link>
  );
}
