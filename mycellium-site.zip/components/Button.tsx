import Link from "next/link";
import type { ReactNode } from "react";

type ButtonProps = {
  href: string;
  children: ReactNode;
  variant?: "gold" | "burgundy" | "dark" | "outline";
  external?: boolean;
  className?: string;
};

const variants: Record<NonNullable<ButtonProps["variant"]>, string> = {
  gold: "bg-gold text-burgundy-dark hover:bg-gold-dark",
  burgundy: "bg-burgundy text-gold hover:bg-burgundy-dark",
  dark: "bg-charcoal text-white hover:bg-black",
  outline: "border border-current bg-transparent hover:bg-white/10",
};

export default function Button({
  href,
  children,
  variant = "gold",
  external = false,
  className = "",
}: ButtonProps) {
  const classes = `inline-flex items-center justify-center rounded-full px-7 py-3 font-heading text-sm font-semibold tracking-wide transition-colors ${variants[variant]} ${className}`;

  if (external) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={classes}>
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  );
}
