import TeamCard from "./TeamCard";
import type { TeamMember } from "@/lib/data";

export default function TeamSection({
  title,
  members,
}: {
  title: string;
  members: TeamMember[];
}) {
  return (
    <div>
      <h2 className="text-center font-heading text-3xl font-extrabold text-gold sm:text-4xl">
        {title}
      </h2>
      <div className="mx-auto mt-10 flex max-w-6xl flex-wrap justify-center gap-x-8 gap-y-12">
        {members.map((member) => (
          <TeamCard key={member.name} member={member} />
        ))}
      </div>
    </div>
  );
}
