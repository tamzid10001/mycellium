import { siteTags } from "@/lib/data";

const floating = [
  { tag: "Climate Educator", style: { left: "59%", top: "5%" }, tone: "text-white", plus: { left: "64%", top: "15%" } },
  { tag: "Climate Justice Advocates", style: { left: "67%", top: "20%" }, tone: "text-gold" },
  { tag: "Ecosystem Builders", style: { left: "9%", top: "36%" }, tone: "text-white", plus: { left: "12.5%", top: "25%" } },
  { tag: "Interdisciplinary Innovators", style: { left: "71%", top: "84%" }, tone: "text-gold" },
  { tag: "Climate Consultants", style: { left: "46%", top: "94%" }, tone: "text-white", plus: { left: "59%", top: "90%" } },
  { tag: "Youth Leadership", style: { left: "14%", top: "70%" }, tone: "text-gold", plus: { left: "8.5%", top: "60%" } },
];

const outline = { fill: "none", stroke: "rgba(255,255,255,0.28)", strokeWidth: 2.5 } as const;

function Structure() {
  const upper = "M672,872 L815,729 A190,190 0 0 1 1118,729 L1258,872 L1165,965 L1024,824 A70,70 0 0 0 907,824 L765,965 Z";
  const capTop = "M441,829 A120,120 0 0 1 629,829 L672,872 L578,965 Z";
  return (
    <svg
      viewBox="420 640 1090 650"
      className="pointer-events-none absolute left-1/2 top-1/2 w-[130%] max-w-[1100px] -translate-x-1/2 -translate-y-1/2 sm:w-[80%]"
      aria-hidden="true"
    >
      <g {...outline}>
        <path d={upper} />
        <path d={capTop} />
        <g transform="translate(1930,0) scale(-1,1)">
          <path d={capTop} />
        </g>
        <g transform="translate(0,1930) scale(1,-1)">
          <path d={upper} />
          <path d={capTop} />
          <g transform="translate(1930,0) scale(-1,1)">
            <path d={capTop} />
          </g>
        </g>
      </g>
    </svg>
  );
}

export default function MyceliumHero() {
  return (
    <div className="relative mx-auto min-h-[560px] max-w-6xl px-6 py-20 sm:min-h-[620px] sm:px-8">
      <Structure />

      <div className="relative z-10 flex min-h-[420px] flex-col items-center justify-center text-center">
        <p className="font-heading text-3xl font-medium tracking-[0.15em] text-gold sm:text-5xl">WE ARE</p>
        <h1 className="mt-2 font-heading text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
          CATALYZING
          <br />
          <span className="font-medium text-gold">CLIMATE SOLUTIONS</span>
        </h1>
        <p className="mt-6 max-w-md text-base leading-relaxed text-white/90 sm:text-lg">
          At Mycellium, we believe that collective action, rooted in strong connections &amp; shared
          purpose, can regenerate the world.
        </p>
      </div>

      {floating.map((item) => (
        <div key={item.tag} className="hidden md:block">
          <span
            className={`absolute font-tag text-base ${item.tone}`}
            style={item.style}
          >
            {item.tag}
          </span>
          {item.plus && (
            <span className="absolute font-tag text-2xl leading-none text-gold" style={item.plus}>
              +
            </span>
          )}
        </div>
      ))}

      <ul className="relative z-10 mt-4 flex flex-wrap justify-center gap-x-6 gap-y-3 md:hidden">
        {siteTags.map((tag) => (
          <li key={tag} className="font-tag text-sm text-gold before:mr-2 before:content-['+']">
            {tag}
          </li>
        ))}
      </ul>
    </div>
  );
}
