import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import type { Article } from "@/lib/data";

export default function FeaturedArticle({ article }: { article: Article }) {
  return (
    <div className="bg-white py-12 sm:py-16">
      <div className="mx-auto max-w-6xl px-6 sm:px-8">
        <a
          href={article.href}
          target="_blank"
          rel="noopener noreferrer"
          className="group grid overflow-hidden rounded-3xl bg-burgundy text-white shadow-xl transition-shadow hover:shadow-2xl lg:grid-cols-2"
        >
          <div className="relative aspect-[16/10] lg:aspect-auto">
            <Image
              src={article.image}
              alt=""
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(min-width: 1024px) 600px, 100vw"
              priority
            />
          </div>
          <div className="flex flex-col justify-center p-6 sm:p-10">
            <span className="inline-block w-fit rounded-full bg-gold px-4 py-1.5 text-xs font-extrabold uppercase tracking-widest text-burgundy-dark">
              Featured
            </span>
            <h2 className="mt-5 font-heading text-2xl font-extrabold leading-tight sm:text-3xl">{article.title}</h2>
            <p className="mt-4 leading-relaxed text-white/90">{article.excerpt}</p>
            <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-gold">
              Read on {article.source}
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </span>
          </div>
        </a>
      </div>
    </div>
  );
}
