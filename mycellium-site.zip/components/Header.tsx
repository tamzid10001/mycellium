"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, Menu, X } from "lucide-react";
import Logo from "./Logo";
import { navLinks, type NavLink } from "@/lib/data";
import SocialIcons from "./SocialIcons";

const programmePaths = ["/programme", "/climate-educators", "/climate-studio", "/climate-connect"];

export default function Header() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const close = () => setOpen(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (link: NavLink) =>
    link.children
      ? programmePaths.includes(pathname) || pathname.startsWith("/programme/")
      : pathname === link.href;

  return (
    <header className="sticky top-0 z-50 bg-burgundy">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4 sm:px-8">
        <Logo />

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Main">
          {navLinks.map((link) => {
            const active = isActive(link);
            const linkClass = `font-heading text-sm tracking-wide transition-colors hover:text-gold ${
              active ? "text-gold" : "text-white"
            }`;
            if (!link.children) {
              return (
                <Link key={link.href} href={link.href} className={linkClass}>
                  {link.label.toUpperCase()}
                </Link>
              );
            }
            return (
              <div key={link.href} className="group relative">
                <Link href={link.href} className={`${linkClass} inline-flex items-center gap-1`}>
                  {link.label.toUpperCase()}
                  <ChevronDown className="h-3.5 w-3.5 transition-transform group-hover:rotate-180" aria-hidden="true" />
                </Link>
                <div className="invisible absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 pt-4 opacity-0 transition duration-150 group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                  <ul className="rounded-2xl bg-white p-2 shadow-xl">
                    {link.children.map((c) => (
                      <li key={c.href}>
                        <Link
                          href={c.href}
                          className="block rounded-xl px-4 py-2.5 text-sm font-semibold text-burgundy transition-colors hover:bg-mist"
                        >
                          {c.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </nav>

        <div className="hidden items-center gap-5 lg:flex">
          <SocialIcons className="text-white" iconClassName="h-4 w-4" />
        </div>

        <button
          type="button"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="text-white lg:hidden"
        >
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {open && (
        <div className="fixed inset-x-0 top-[64px] bottom-0 z-40 flex flex-col overflow-y-auto bg-white px-6 py-8 lg:hidden">
          <nav className="flex flex-col gap-5" aria-label="Mobile">
            <Link
              href="/"
              onClick={close}
              className={`font-heading text-2xl ${
                pathname === "/" ? "text-burgundy underline decoration-2 underline-offset-8" : "text-black"
              }`}
            >
              HOME
            </Link>
            {navLinks.map((link) => (
              <div key={link.href}>
                <Link
                  href={link.href}
                  onClick={close}
                  className={`font-heading text-2xl ${
                    isActive(link) ? "text-burgundy underline decoration-2 underline-offset-8" : "text-black"
                  }`}
                >
                  {link.label.toUpperCase()}
                </Link>
                {link.children && (
                  <ul className="mt-3 space-y-2 border-l-2 border-gold pl-4">
                    {link.children.map((c) => (
                      <li key={c.href}>
                        <Link
                          href={c.href}
                          onClick={close}
                          className="block text-base font-semibold text-burgundy"
                        >
                          {c.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </nav>
          <div className="mt-auto flex justify-center gap-6 pt-10">
            <SocialIcons className="text-black" iconClassName="h-6 w-6" />
          </div>
        </div>
      )}
    </header>
  );
}
