import Image from "next/image";
import { ArrowUpRight, MapPin } from "lucide-react";
import { dhakaContext, pastDhakaEvents } from "@/lib/data";

export default function DhakaClimate() {
  const [main, second] = dhakaContext.photos;
  return (
    <section className="bg-white py-16 sm:py-24" aria-labelledby="dhaka-climate-heading">
      <div className="mx-auto max-w-6xl px-6 sm:px-8">
        <h2
          id="dhaka-climate-heading"
          className="text-center font-heading text-3xl font-extrabold text-burgundy sm:text-4xl"
        >
          {dhakaContext.title}
        </h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-black/70">
          Youth-led climate action, gatherings, and collaboration in Dhaka.
        </p>

        <div className="mt-14 grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <div className="space-y-4 leading-relaxed text-charcoal">
              {dhakaContext.intro.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <dl className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
              {dhakaContext.facts.map((f) => (
                <div key={f.label} className="rounded-2xl bg-mist p-4 text-center">
                  <dd className="font-heading text-2xl font-extrabold text-burgundy">{f.value}</dd>
                  <dt className="mt-1 text-xs font-semibold uppercase tracking-wider text-charcoal/70">{f.label}</dt>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative pb-8 sm:pl-6">
            <div className="relative aspect-[4/5] overflow-hidden rounded-3xl shadow-xl">
              <Image src={main.src} alt={main.alt} fill className="object-cover" sizes="(min-width: 1024px) 520px, 100vw" />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-5 pt-16 text-white">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <MapPin className="h-4 w-4 text-gold" aria-hidden="true" />
                  Dhaka, Bangladesh
                </p>
              </div>
            </div>
            <div className="absolute bottom-0 left-0 hidden aspect-[4/3] w-1/2 overflow-hidden rounded-2xl border-8 border-white shadow-xl sm:block">
              <Image src={second.src} alt={second.alt} fill className="object-cover" sizes="260px" />
            </div>
          </div>
        </div>

        <div className="mt-24">
          <h3 className="font-heading text-2xl font-extrabold text-burgundy-dark">Already Happened</h3>
          {pastDhakaEvents.map((e) => (
            <article key={e.title} className="mt-6 grid gap-8 rounded-3xl bg-mist p-6 sm:p-8 lg:grid-cols-[1.1fr_1fr]">
              <div>
                <h4 className="font-heading text-xl font-bold text-burgundy">{e.title}</h4>
                <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-black/60">
                  <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                  {e.venue}
                </p>
                <p className="mt-4 leading-relaxed text-charcoal/80">{e.summary}</p>
                {e.href && (
                  <a
                    href={e.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 hover:decoration-burgundy"
                  >
                    Read the story
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                {dhakaContext.nextgenPhotos.map((p, i) => (
                  <div
                    key={p.src}
                    className={`relative overflow-hidden rounded-xl ${i === 0 ? "col-span-2 aspect-[16/9]" : "aspect-[4/3]"}`}
                  >
                    <Image src={p.src} alt={p.alt} fill className="object-cover" sizes="(min-width: 1024px) 340px, 50vw" />
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
