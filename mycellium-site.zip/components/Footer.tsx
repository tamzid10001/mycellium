import Link from "next/link";
import { navLinks } from "@/lib/data";
import { programLinks } from "@/lib/programs";
import SocialIcons from "./SocialIcons";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="relative bg-gold pt-16 pb-10 text-burgundy-dark">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-8 px-6 text-center">
        <div className="opacity-90">
          <Logo light={false} />
        </div>

        <nav className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
          <Link href="/" className="font-heading text-sm tracking-wide hover:underline">
            HOME
          </Link>
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className="font-heading text-sm tracking-wide hover:underline">
              {link.label.toUpperCase()}
            </Link>
          ))}
        </nav>

        <nav aria-label="Programs" className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
          {programLinks.map((link) => (
            <Link key={link.href} href={link.href} className="text-sm font-semibold hover:underline">
              {link.label}
            </Link>
          ))}
        </nav>

        <SocialIcons className="text-burgundy-dark" />

        <p className="text-xs tracking-wide opacity-80">
          MYCELLIUM PTY LTD | ABN 19 691 518 766
        </p>
      </div>
    </footer>
  );
}
