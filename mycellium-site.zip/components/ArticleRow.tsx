import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import type { Article } from "@/lib/data";

export default function ArticleRow({
  article,
  index,
}: {
  article: Article;
  index: number;
}) {
  const isGold = index % 2 === 1;
  const imageFirst = index % 2 === 0;

  return (
    <div className={isGold ? "bg-gold" : "bg-burgundy"}>
      <div
        className={`mx-auto grid max-w-6xl gap-8 px-6 py-12 sm:px-8 sm:py-16 lg:grid-cols-2 lg:items-center lg:gap-12 ${
          imageFirst ? "" : "lg:[&>div:first-child]:order-2"
        }`}
      >
        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl">
          <Image
            src={article.image}
            alt={article.title}
            fill
            className="object-cover"
            sizes="(min-width: 1024px) 500px, 100vw"
          />
        </div>
        <div>
          <h3
            className={`font-heading text-2xl font-extrabold sm:text-3xl ${
              isGold ? "text-burgundy" : "text-gold"
            }`}
          >
            {article.title}
          </h3>
          <p className={`mt-4 leading-relaxed ${isGold ? "text-burgundy-dark" : "text-white/90"}`}>
            {article.excerpt}
          </p>
          <a
            href={article.href}
            target="_blank"
            rel="noopener noreferrer"
            className={`mt-6 inline-flex items-center gap-2 rounded-full px-6 py-3 font-heading text-sm font-semibold tracking-wide transition-opacity hover:opacity-90 ${
              isGold ? "bg-charcoal text-white" : "bg-white text-burgundy"
            }`}
          >
            Read more
            <ArrowUpRight className="h-4 w-4" />
          </a>
          <p className={`mt-3 text-xs uppercase tracking-widest ${isGold ? "text-burgundy-dark/70" : "text-white/60"}`}>
            {article.source}
          </p>
        </div>
      </div>
    </div>
  );
}
