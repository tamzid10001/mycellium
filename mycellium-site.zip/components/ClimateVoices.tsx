import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { articles, climateVoices } from "@/lib/data";

export default function ClimateVoices() {
  const featured = articles.slice(0, 3);
  return (
    <section className="bg-burgundy py-16 text-white sm:py-24" aria-labelledby="climate-voices-heading">
      <div className="mx-auto max-w-6xl px-6 sm:px-8">
        <h2 id="climate-voices-heading" className="font-heading text-3xl font-extrabold text-gold sm:text-4xl">
          {climateVoices.title}
        </h2>
        <p className="mt-3 max-w-2xl text-white/90">{climateVoices.intro}</p>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {featured.map((a) => (
            <article key={a.title} className="flex h-full flex-col overflow-hidden rounded-2xl bg-white text-black">
              <div className="relative aspect-[4/3]">
                <Image src={a.image} alt="" fill className="object-cover" sizes="(min-width: 768px) 360px, 100vw" />
              </div>
              <div className="flex flex-1 flex-col p-6">
                <p className="text-xs font-semibold uppercase tracking-widest text-black/50">{a.source}</p>
                <h3 className="mt-2 font-heading text-lg font-bold leading-snug text-burgundy">{a.title}</h3>
                <p className="mt-3 line-clamp-4 text-sm leading-relaxed text-black/70">{a.excerpt}</p>
                <a
                  href={a.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-auto inline-flex items-center gap-1 pt-4 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 transition-colors hover:decoration-burgundy"
                >
                  Read more
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-10">
          <Link
            href="/programme/climate-voices"
            className="inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3 font-heading text-sm font-semibold text-burgundy-dark transition-colors hover:bg-gold-dark"
          >
            Explore the Climate Voices programme
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </section>
  );
}
