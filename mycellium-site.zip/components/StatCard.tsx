export default function StatCard({
  value,
  label,
  detail,
}: {
  value: string;
  label: string;
  detail?: string;
}) {
  return (
    <div className="rounded-2xl bg-mint p-6 shadow-sm">
      <p className="font-heading text-3xl font-bold text-burgundy sm:text-4xl">{value}</p>
      <div className="mt-3 flex items-start gap-2">
        <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-teal" aria-hidden="true" />
        <p className="text-sm font-medium text-[#241016]">{label}</p>
      </div>
      {detail && <p className="mt-2 text-sm text-[#241016]/70">{detail}</p>}
    </div>
  );
}
