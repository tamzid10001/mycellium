import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, CalendarDays, MapPin, Newspaper } from "lucide-react";
import { announcementPoster, dhakaClimateWeek as dcw } from "@/lib/data";

export default function Announcements() {
  return (
    <section className="relative overflow-hidden bg-gold py-16 sm:py-24" aria-labelledby="announcements-heading">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 sm:px-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,2.3fr)] lg:gap-14">
        <div className="flex flex-col items-center text-center lg:h-full lg:items-start lg:justify-center lg:text-left">
          <div className="relative aspect-square w-full max-w-[360px] overflow-hidden rounded-3xl shadow-xl sm:max-w-[400px] lg:max-w-none">
            <Image
              src={announcementPoster.src}
              alt={announcementPoster.alt}
              fill
              className="object-cover"
              sizes="(min-width: 1024px) 33vw, (min-width: 640px) 400px, 360px"
            />
          </div>
          <div className="mt-6">
            <p className="inline-flex items-center gap-2 rounded-full bg-burgundy-dark px-4 py-1.5 text-xs font-extrabold uppercase tracking-widest text-gold">
              <span className="relative flex h-2.5 w-2.5" aria-hidden="true">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75 motion-reduce:animate-none" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-500" />
              </span>
              On air · Latest news
            </p>
            <h2
              id="announcements-heading"
              className="mt-4 font-heading text-3xl font-extrabold text-burgundy-dark sm:text-4xl"
            >
              Announcements
            </h2>
            <p className="mt-3 max-w-sm text-burgundy-dark/80">
              The latest news and events from Mycellium and our community.
            </p>
          </div>
        </div>

        <article className="relative overflow-hidden rounded-3xl bg-burgundy text-white shadow-xl">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(253,182,20,0.28),transparent_55%)]"
            aria-hidden="true"
          />
          <div className="relative p-6 sm:p-10">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <Image
                src="/images/dhaka/dcw-logo-white.png"
                alt="Dhaka Climate Week"
                width={804}
                height={273}
                className="h-12 w-auto sm:h-14"
              />
              <span className="inline-block rounded-xl bg-gold px-4 py-1.5 text-xs font-extrabold uppercase leading-snug tracking-wider text-burgundy-dark">
                {dcw.eyebrow}
              </span>
            </div>

            <div className="mt-8 grid gap-6 sm:grid-cols-[auto_1fr] sm:items-center">
              <div className="w-fit rounded-2xl bg-gold px-6 py-4 text-center text-burgundy-dark">
                <p className="font-heading text-4xl font-extrabold leading-none sm:text-5xl">17–21</p>
                <p className="mt-1 text-xs font-extrabold uppercase tracking-widest">January 2027</p>
              </div>
              <div>
                <h3 className="font-heading text-3xl font-extrabold leading-tight sm:text-4xl">{dcw.title}</h3>
                <p className="mt-1 font-heading text-lg font-semibold text-gold">{dcw.tagline}</p>
              </div>
            </div>

            <p className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold uppercase tracking-wider">
              <span className="inline-flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-gold" aria-hidden="true" />
                {dcw.dates}
              </span>
              <span className="inline-flex items-center gap-2">
                <MapPin className="h-4 w-4 text-gold" aria-hidden="true" />
                {dcw.location}
              </span>
            </p>

            <p className="mt-5 max-w-3xl leading-relaxed text-white/90">{dcw.summary}</p>

            <dl className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {dcw.stats.map((s) => (
                <div key={s.label} className="rounded-2xl bg-white/10 p-4 text-center">
                  <dt className="sr-only">{s.label}</dt>
                  <dd className="font-heading text-2xl font-extrabold text-gold sm:text-3xl">{s.value}</dd>
                  <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-white/80">{s.label}</p>
                </div>
              ))}
            </dl>

            <div className="mt-8 rounded-2xl bg-white p-5 text-burgundy-dark sm:p-6">
              <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-burgundy">
                <Newspaper className="h-4 w-4" aria-hidden="true" />
                {dcw.news.label}
              </p>
              <h4 className="mt-2 font-heading text-lg font-bold text-burgundy">{dcw.news.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-black/75">{dcw.news.text}</p>
              <a
                href={dcw.news.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 hover:decoration-burgundy"
              >
                Read the report on {dcw.news.source}
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/programme/dhaka-climate-week#programme"
                className="inline-flex items-center gap-1.5 rounded-full bg-gold px-6 py-3 text-sm font-semibold text-burgundy-dark transition-colors hover:bg-gold-dark"
              >
                See the full programme
              </Link>
              {dcw.links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`inline-flex items-center gap-1.5 rounded-full px-6 py-3 text-sm font-semibold transition-colors ${
                    "border border-white/60 text-white hover:bg-white/10"
                  }`}
                >
                  {l.label}
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>
        </article>
      </div>
    </section>
  );
}
