import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { programLinks } from "@/lib/programs";

export default function ProgramExplore({ current }: { current: string }) {
  const others = programLinks.filter((l) => l.href !== current);
  return (
    <section className="bg-burgundy py-14 text-white sm:py-16">
      <div className="mx-auto max-w-6xl px-6 text-center sm:px-8">
        <h2 className="font-heading text-2xl font-extrabold text-gold sm:text-3xl">Explore more from Mycellium</h2>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          {others.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3 font-heading text-sm font-semibold text-burgundy-dark transition-colors hover:bg-gold-dark"
            >
              {l.label}
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          ))}
          <Link
            href="/"
            className="inline-flex items-center rounded-full border border-white/60 px-7 py-3 font-heading text-sm font-semibold transition-colors hover:bg-white/10"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </section>
  );
}
