import {
  ArrowUpRight,
  Building2,
  Coins,
  Cpu,
  Droplets,
  GraduationCap,
  Handshake,
  Landmark,
  Recycle,
  Sprout,
  TreePine,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { dhakaClimateWeek as dcw } from "@/lib/data";

const icons: Record<string, LucideIcon> = {
  landmark: Landmark,
  graduation: GraduationCap,
  handshake: Handshake,
  coins: Coins,
  tree: TreePine,
  building: Building2,
  zap: Zap,
  droplets: Droplets,
  cpu: Cpu,
  sprout: Sprout,
  recycle: Recycle,
};

const themeTones = [
  "bg-burgundy text-white",
  "bg-gold text-burgundy-dark",
  "bg-charcoal text-white",
  "bg-burgundy-light text-white",
  "bg-gold text-burgundy-dark",
  "bg-burgundy text-white",
];

export default function DhakaProgramme() {
  const topics = [...dcw.topics, ...dcw.topics];
  return (
    <section id="programme" className="scroll-mt-16 bg-mist py-16 sm:py-24" aria-labelledby="programme-heading">
      <div className="mx-auto max-w-6xl px-6 sm:px-8">
        <p className="text-sm font-extrabold uppercase tracking-widest text-burgundy-light">
          {dcw.title} · {dcw.dates}
        </p>
        <h2 id="programme-heading" className="mt-2 font-heading text-3xl font-extrabold text-burgundy sm:text-5xl">
          The Programme
        </h2>
        <p className="mt-3 max-w-3xl text-lg font-semibold text-charcoal">
          Five days. Six themes. One delta — all the climate conversations that matter, in one week.
        </p>
        <p className="mt-3 max-w-3xl leading-relaxed text-charcoal/80">{dcw.mission}</p>

        <h3 className="mt-14 font-heading text-xl font-extrabold text-burgundy">Five days</h3>
        <ol className="relative mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <span
            className="pointer-events-none absolute left-0 right-0 top-[38px] hidden border-t-2 border-dashed border-burgundy/30 lg:block"
            aria-hidden="true"
          />
          {dcw.programme.map((d, i) => {
            const Icon = icons[d.icon];
            return (
              <li key={d.title} className="relative rounded-3xl bg-white p-5 shadow-sm">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-burgundy text-gold ring-4 ring-mist">
                  <Icon className="h-7 w-7" aria-hidden="true" />
                </span>
                <p className="mt-4 text-xs font-extrabold uppercase tracking-widest text-burgundy-light">
                  Day {String(i + 1).padStart(2, "0")}
                </p>
                <p className="mt-1 font-heading text-base font-bold leading-snug text-charcoal">{d.title}</p>
              </li>
            );
          })}
        </ol>

        <h3 className="mt-14 font-heading text-xl font-extrabold text-burgundy">Six themes</h3>
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {dcw.themes.map((t, i) => {
            const Icon = icons[t.icon];
            return (
              <li key={t.title} className={`flex flex-col rounded-3xl p-6 ${themeTones[i % themeTones.length]}`}>
                <Icon className="h-9 w-9 opacity-90" aria-hidden="true" />
                <p className="mt-4 text-xs font-extrabold uppercase tracking-widest opacity-80">{t.label}</p>
                <p className="mt-1 font-heading text-xl font-extrabold leading-snug">{t.title}</p>
                <p className="mt-2 text-sm leading-relaxed opacity-90">{t.text}</p>
              </li>
            );
          })}
        </ul>

        <h3 className="mt-14 font-heading text-xl font-extrabold text-burgundy">Every topic, four lenses</h3>
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {dcw.lenses.map((l, i) => (
            <li key={l.name} className="rounded-3xl border-2 border-burgundy/20 bg-white p-5">
              <p className="text-xs font-extrabold uppercase tracking-widest text-burgundy-light">Lens {i + 1}</p>
              <p className="mt-1 font-heading text-lg font-extrabold text-burgundy">{l.name}</p>
              <p className="mt-2 text-sm leading-relaxed text-charcoal/80">{l.question}</p>
            </li>
          ))}
        </ul>

        <div className="mt-10">
          <a
            href="https://www.dhkclimateweek.org/#contact"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-burgundy px-7 py-3 font-heading text-sm font-semibold text-gold transition-colors hover:bg-burgundy-dark"
          >
            Get involved in the programme
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </div>

      <div className="mt-16 overflow-hidden bg-burgundy py-4" aria-hidden="true">
        <div className="marquee-track flex w-max gap-10 whitespace-nowrap">
          {topics.map((t, i) => (
            <span key={i} className="flex items-center gap-10 font-heading text-sm font-bold uppercase tracking-widest text-gold">
              {t}
              <span className="text-white/40">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
