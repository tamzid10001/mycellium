import Image from "next/image";
import { LinkedinIcon, GlobeIcon } from "./icons";
import type { TeamMember } from "@/lib/data";

export default function TeamCard({ member }: { member: TeamMember }) {
  return (
    <div className="flex w-[150px] shrink-0 flex-col items-center text-center sm:w-52 lg:w-60">
      <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-full bg-white/10 sm:h-36 sm:w-36">
        <Image src={member.image} alt={member.name} fill className="object-cover" sizes="144px" />
      </div>
      <h3 className="mt-4 font-heading text-base font-bold leading-snug text-gold sm:text-lg">
        {member.name}
      </h3>
      <div className="mt-1">
        <p className="text-xs leading-snug text-white/90 sm:text-sm">{member.role}</p>
        {member.org && (
          <p className="text-xs leading-snug text-white/90 sm:text-sm">{member.org}</p>
        )}
      </div>
      <div className="mt-3 flex gap-3">
        {member.linkedin && (
          <a
            href={member.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${member.name} on LinkedIn`}
            className="text-white/80 transition-colors hover:text-gold"
          >
            <LinkedinIcon className="h-5 w-5" />
          </a>
        )}
        {member.website && (
          <a
            href={member.website}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${member.name} website`}
            className="text-white/80 transition-colors hover:text-gold"
          >
            <GlobeIcon className="h-5 w-5" />
          </a>
        )}
      </div>
    </div>
  );
}
