type Tone = "burgundy" | "dark" | "white" | "gold" | "deep";

type Node = { cx: number; cy: number; r: number; tone: Tone; text: string };

const tones: Record<Tone, { fill: string; color: string }> = {
  burgundy: { fill: "#9f1e5b", color: "#fdb614" },
  dark: { fill: "#232323", color: "#ffffff" },
  white: { fill: "#ffffff", color: "#77003c" },
  gold: { fill: "#fdb614", color: "#77003c" },
  deep: { fill: "#77003c", color: "#ffffff" },
};

const nodes: Node[] = [
  { cx: 200, cy: 334, r: 100, tone: "burgundy", text: "Empower youth & startups through climate education" },
  { cx: 122, cy: 582, r: 100, tone: "burgundy", text: "Foster innovation for sustainable business models" },
  { cx: 200, cy: 852, r: 100, tone: "burgundy", text: "Build collaboration between academia, private sector, & civil society" },
  { cx: 598, cy: 322, r: 100, tone: "dark", text: "Equipping students with climate education, cross-cultural collaboration, & leadership skills to drive global impact" },
  { cx: 459, cy: 582, r: 100, tone: "dark", text: "Support startups to design & test scalable climate solutions" },
  { cx: 733, cy: 582, r: 100, tone: "dark", text: "Increase visibility & investment in climate innovation" },
  { cx: 597, cy: 844, r: 100, tone: "dark", text: "Access to knowledge, global resources & skilled professionals for mentoring young innovators" },
  { cx: 1080, cy: 322, r: 100, tone: "white", text: "Skilled youth workforce driving green transitions" },
  { cx: 988, cy: 584, r: 100, tone: "white", text: "Climate-smart enterprises with sustainable business models" },
  { cx: 1082, cy: 853, r: 100, tone: "white", text: "Stronger collaboration between education, industry, & communities" },
  { cx: 1468, cy: 322, r: 100, tone: "gold", text: "Youth innovators & students" },
  { cx: 1380, cy: 586, r: 100, tone: "gold", text: "Climate startups & social enterprises" },
  { cx: 1462, cy: 852, r: 100, tone: "gold", text: "Cities, local governments, & ecosystem builders" },
  { cx: 1802, cy: 575, r: 178, tone: "deep", text: "A global ecosystem where youth-led innovation accelerates climate action, supports sustainable livelihoods, & drives just transitions across the Global South." },
];

const dividers = [305, 833, 1220, 1590];

const headers = [
  { x: 48, y: 170, lines: ["Working with", "our partners to…"] },
  { x: 334, y: 170, lines: ["Which makes it", "possible to…"] },
  { x: 857, y: 170, lines: ["Which contributes", "to…"] },
  { x: 1251, y: 172, lines: ["Supporting…"] },
  { x: 1629, y: 163, lines: ["To achieve our long", "term goal of…"] },
];

const footers = [
  { x: 22, y: 965, lines: ["System", "Change Approach"] },
  { x: 332, y: 982, lines: ["Outcomes"] },
  { x: 688, y: 982, lines: ["0–2 years"] },
  { x: 865, y: 968, lines: ["System", "Change Objective"] },
  { x: 1100, y: 982, lines: ["2–3 years"] },
  { x: 1245, y: 980, lines: ["Target Groups"] },
  { x: 1621, y: 964, lines: ["Social", "Change Goal"] },
  { x: 1863, y: 969, lines: ["5 years"] },
];

const dash = { fill: "none", stroke: "#9f1e5b", strokeWidth: 4, strokeDasharray: "14 10" } as const;
const faint = { fill: "none", stroke: "#9f1e5b", strokeWidth: 1.5, strokeDasharray: "5 5", opacity: 0.6 } as const;

function Label({ x, y, lines }: { x: number; y: number; lines: string[] }) {
  return (
    <text x={x} y={y} fontSize={23} fontWeight={700} fill="#111" fontFamily="var(--font-montserrat), sans-serif">
      {lines.map((l, i) => (
        <tspan key={l} x={x} dy={i === 0 ? 0 : 30}>
          {l}
        </tspan>
      ))}
    </text>
  );
}

export default function TheoryOfChange() {
  return (
    <section className="bg-[#e0e0e0] py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <h2 className="font-heading text-2xl font-extrabold text-burgundy sm:text-4xl">
          Theory of change of Mycellium
        </h2>
        <p className="mt-2 text-xs font-semibold text-burgundy md:hidden">Swipe sideways to see the full diagram →</p>
        <div className="mt-6 overflow-x-auto">
          <svg
            viewBox="0 0 2000 1066"
            className="h-auto w-full min-w-[900px]"
            role="img"
            aria-label="Theory of change of Mycellium"
          >
            <polygon points="520,1066 1000,600 1480,1066" fill="#000" opacity="0.04" />
            <polygon points="150,600 610,140 1070,600 610,1066" fill="#000" opacity="0.035" />
            <polygon points="1300,540 1700,140 2000,440 2000,1066 1500,1066" fill="#000" opacity="0.035" />

            <path d="M20,135 H1970" {...dash} />
            {dividers.map((x) => (
              <path key={x} d={`M${x},135 V1040`} {...dash} />
            ))}

            <path d="M20,250 H1580 M20,585 H1600 M20,907 H1450" {...faint} />

            <path d="M100,340 C10,480 10,720 100,850" {...dash} />
            <path d="M500,340 C330,470 330,700 500,815" {...dash} />
            <path d="M1043,420 L1030,490 M1020,680 L1035,760" {...dash} />
            <path d="M1430,420 L1412,490 M1398,685 L1412,765" {...dash} />

            {headers.map((h) => (
              <Label key={h.x} {...h} />
            ))}
            {footers.map((f) => (
              <Label key={f.x + f.lines[0]} {...f} />
            ))}

            {nodes.map((n) => {
              const t = tones[n.tone];
              const size = n.r > 150 ? 24 : n.text.length > 85 ? 17 : n.text.length > 55 ? 19 : 21;
              return (
                <g key={n.text}>
                  <circle cx={n.cx} cy={n.cy} r={n.r} fill={t.fill} />
                  <foreignObject x={n.cx - n.r * 0.86} y={n.cy - n.r * 0.86} width={n.r * 1.72} height={n.r * 1.72}>
                    <div
                      style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        textAlign: "center",
                        color: t.color,
                        fontSize: size,
                        fontWeight: 700,
                        lineHeight: 1.15,
                        fontFamily: "var(--font-montserrat), sans-serif",
                      }}
                    >
                      {n.text}
                    </div>
                  </foreignObject>
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </section>
  );
}
