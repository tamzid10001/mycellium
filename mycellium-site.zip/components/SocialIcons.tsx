import { InstagramIcon, LinkedinIcon } from "./icons";
import { socialLinks } from "@/lib/data";

export default function SocialIcons({
  className = "",
  iconClassName = "h-5 w-5",
}: {
  className?: string;
  iconClassName?: string;
}) {
  return (
    <div className={`flex items-center gap-5 ${className}`}>
      <a
        href={socialLinks.instagram}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Mycellium on Instagram"
        className="transition-opacity hover:opacity-70"
      >
        <InstagramIcon className={iconClassName} />
      </a>
      <a
        href={socialLinks.linkedin}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Mycellium on LinkedIn"
        className="transition-opacity hover:opacity-70"
      >
        <LinkedinIcon className={iconClassName} />
      </a>
    </div>
  );
}
