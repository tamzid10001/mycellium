"use client";

import { useState, type FormEvent } from "react";
import { contactFormFields } from "@/lib/data";

type Status = "idle" | "submitting" | "success" | "error";

export default function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");

    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Request failed");
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="rounded-2xl border border-gold/40 bg-white/5 p-8 text-center">
        <p className="font-heading text-xl font-bold text-gold">Thank you!</p>
        <p className="mt-2 text-white/90">
          We&apos;ve received your message and will get back to you after reviewing your request.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {contactFormFields.map((field) => (
        <div key={field.name}>
          <label htmlFor={field.name} className="block text-sm font-medium text-white">
            {field.label}
            {field.required && <span className="text-gold"> *</span>}
          </label>
          <input
            id={field.name}
            name={field.name}
            type={"type" in field ? field.type : "text"}
            required={field.required}
            placeholder={field.placeholder}
            className="mt-2 w-full rounded-md border border-white/40 bg-transparent px-4 py-3 text-white placeholder-white/50 outline-none transition-colors focus:border-gold"
          />
        </div>
      ))}

      <div>
        <label htmlFor="message" className="block text-sm font-medium text-white">
          What is it about?
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          placeholder="Please tell us how we can assist you."
          className="mt-2 w-full rounded-md border border-white/40 bg-transparent px-4 py-3 text-white placeholder-white/50 outline-none transition-colors focus:border-gold"
        />
      </div>

      <button
        type="submit"
        disabled={status === "submitting"}
        className="w-full rounded-full bg-gold px-7 py-3.5 font-heading text-sm font-semibold tracking-wide text-burgundy-dark transition-colors hover:bg-gold-dark disabled:opacity-60"
      >
        {status === "submitting" ? "Submitting…" : "Submit"}
      </button>

      {status === "error" && (
        <p className="text-sm text-red-200">
          Something went wrong sending your message. Please try again or email us directly.
        </p>
      )}
    </form>
  );
}
