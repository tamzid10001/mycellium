import Image from "next/image";

type ImpactStat = { value: string; label: string };

export default function ImpactBlock({
  title,
  headline,
  detail,
  stats,
  images,
  reverse = false,
}: {
  title: string;
  headline: string;
  detail: string;
  stats: ImpactStat[];
  images: string[];
  reverse?: boolean;
}) {
  return (
    <div>
      <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">{title}</h2>

      <div
        className={`mt-8 grid gap-3 sm:grid-cols-3 ${reverse ? "sm:[&>*:first-child]:order-3" : ""}`}
      >
        <div className="relative flex flex-col justify-center overflow-hidden rounded-2xl bg-burgundy p-6 text-white sm:col-span-1">
          <p className="font-heading text-xl font-extrabold leading-tight sm:text-2xl">
            {headline}
          </p>
          <p className="mt-3 text-sm text-white/85">{detail}</p>
        </div>
        {images.slice(0, 2).map((src, i) => (
          <div key={i} className="relative aspect-[4/3] overflow-hidden rounded-2xl sm:aspect-auto">
            <Image src={src} alt="" fill className="object-cover" sizes="(min-width: 640px) 33vw, 100vw" />
          </div>
        ))}
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-2xl bg-mist p-6">
            <p className="font-heading text-2xl font-bold text-burgundy">{stat.value}</p>
            <p className="mt-2 text-sm text-black/70">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
