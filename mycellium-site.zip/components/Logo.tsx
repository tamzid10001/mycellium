import Image from "next/image";
import Link from "next/link";

export default function Logo({ light = true }: { light?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5 shrink-0" aria-label="Mycellium home">
      <Image
        src="/images/logo-icon.png"
        alt=""
        width={32}
        height={32}
        className={light ? "invert brightness-0 contrast-200 invert-0 brightness-200" : ""}
        style={light ? { filter: "brightness(0) invert(1)" } : undefined}
        priority
      />
      <span
        className={`font-heading font-semibold tracking-[0.15em] text-lg ${
          light ? "text-white" : "text-burgundy"
        }`}
      >
        MYCELLIUM
      </span>
    </Link>
  );
}
