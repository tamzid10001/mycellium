import Image from "next/image";
import { partners } from "@/lib/data";

export default function PartnerLogos() {
  return (
    <section className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-6 text-center sm:px-8">
        <h2 className="font-heading text-3xl font-extrabold text-burgundy sm:text-4xl">
          Our Partners
        </h2>
        <div className="mt-10 grid grid-cols-2 divide-y divide-x divide-gray-200 border border-gray-200 sm:grid-cols-3 lg:grid-cols-5">
          {partners.map((partner, i) => (
            <div
              key={i}
              className="flex aspect-[3/2] items-center justify-center p-6"
            >
              <div className="relative h-full w-full">
                <Image
                  src={partner.logo}
                  alt={partner.name}
                  fill
                  className="object-contain"
                  sizes="200px"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
