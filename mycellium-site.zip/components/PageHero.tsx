import type { ReactNode } from "react";
import Image from "next/image";
import WaveDivider from "./WaveDivider";

type PageHeroProps = {
  eyebrow?: string;
  title: ReactNode;
  intro?: string;
  tags?: string[];
  children?: ReactNode;
  wave?: boolean;
  waveColor?: string;
  backgroundImage?: string;
};

export default function PageHero({
  eyebrow = "WE ARE",
  title,
  intro,
  tags,
  children,
  wave = true,
  waveColor = "text-white",
  backgroundImage,
}: PageHeroProps) {
  return (
    <section className="relative overflow-hidden bg-burgundy pb-20 pt-14 text-white sm:pb-28 sm:pt-20">
      {backgroundImage && (
        <div className="absolute inset-0" aria-hidden="true">
          <Image src={backgroundImage} alt="" fill priority className="object-cover opacity-25" sizes="100vw" />
          <div className="absolute inset-0 bg-gradient-to-b from-burgundy/70 via-burgundy/85 to-burgundy" />
        </div>
      )}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, transparent, transparent 60px, rgba(253,182,20,0.5) 60px, rgba(253,182,20,0.5) 61px), repeating-linear-gradient(-45deg, transparent, transparent 60px, rgba(253,182,20,0.5) 60px, rgba(253,182,20,0.5) 61px)",
        }}
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-6xl px-6 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-start">
          <div>
            {eyebrow && (
              <p className="font-heading text-lg font-semibold tracking-[0.2em] text-gold sm:text-xl">
                {eyebrow}
              </p>
            )}
            <h1 className="mt-2 font-heading text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
              {title}
            </h1>
          </div>
          {intro && (
            <p className="max-w-md text-base leading-relaxed text-white/90 lg:pt-3">
              {intro}
            </p>
          )}
        </div>

        {tags && tags.length > 0 && (
          <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-3">
            {tags.map((tag) => (
              <li
                key={tag}
                className="font-tag text-sm tracking-wide text-gold before:mr-2 before:content-['+']"
              >
                {tag}
              </li>
            ))}
          </ul>
        )}

        {children}
      </div>

      {wave && <WaveDivider color={waveColor} />}
    </section>
  );
}
