import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { programLinks } from "@/lib/programs";

export default function ProgramSwitcher({ current }: { current: string }) {
  return (
    <nav aria-label="Programs" className="border-b border-black/10 bg-white">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-8 gap-y-2 px-6 py-4 sm:px-8">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-burgundy underline decoration-burgundy/40 underline-offset-4 transition-colors hover:decoration-burgundy"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Home
        </Link>
        <ul className="flex flex-wrap gap-x-6 gap-y-2">
          {programLinks.map((link) => {
            const active = link.href === current;
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={active ? "page" : undefined}
                  className={`text-sm font-semibold transition-colors ${
                    active
                      ? "text-burgundy underline decoration-gold decoration-2 underline-offset-8"
                      : "text-black/60 hover:text-burgundy"
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
