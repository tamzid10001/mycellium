import Image from "next/image";
import type { Photo } from "@/lib/programs";

export default function PhotoGrid({
  photos,
  fit = "cover",
  className = "",
}: {
  photos: Photo[];
  fit?: "cover" | "contain";
  className?: string;
}) {
  return (
    <div className={`grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 ${className}`}>
      {photos.map((photo) => (
        <div
          key={photo.src}
          className={`relative overflow-hidden rounded-lg ${
            fit === "contain" ? "aspect-square bg-white/10" : "aspect-[4/3]"
          }`}
        >
          <Image
            src={photo.src}
            alt={photo.alt}
            fill
            className={fit === "contain" ? "object-contain" : "object-cover"}
            sizes="(min-width: 1024px) 280px, 50vw"
          />
        </div>
      ))}
    </div>
  );
}
