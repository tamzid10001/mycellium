import PhotoGrid from "./PhotoGrid";
import type { ConnectEvent } from "@/lib/programs";

const tones = {
  gray: { bg: "bg-mist", title: "text-burgundy", text: "text-charcoal", sub: "text-charcoal" },
  amber: { bg: "bg-gold", title: "text-burgundy", text: "text-burgundy", sub: "text-burgundy-dark" },
  berry: { bg: "bg-burgundy-light", title: "text-gold", text: "text-white", sub: "text-white" },
} as const;

export default function EventSection({ event }: { event: ConnectEvent }) {
  const t = tones[event.tone];
  return (
    <section id={event.id} className={`${t.bg} scroll-mt-16 py-14 sm:py-20`}>
      <div className="mx-auto max-w-6xl px-6 sm:px-8">
        <h2 className={`max-w-4xl font-heading text-3xl font-extrabold sm:text-4xl ${t.title}`}>{event.title}</h2>
        <div className={`mt-6 max-w-4xl space-y-4 leading-relaxed ${t.text}`}>
          {event.blocks.map((b, i) => {
            if (b.type === "h") {
              return (
                <h3 key={i} className={`pt-3 font-heading text-lg font-bold ${t.sub}`}>
                  {b.text}
                </h3>
              );
            }
            if (b.type === "ul") {
              return (
                <div key={i}>
                  {b.label && <p>{b.label}</p>}
                  <ul className="mt-1 list-disc space-y-1 pl-6">
                    {b.items.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              );
            }
            if (b.type === "a") {
              return (
                <p key={i}>
                  <a
                    href={b.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-semibold underline decoration-current/50 underline-offset-4 hover:decoration-current"
                  >
                    {b.text} ↗
                  </a>
                </p>
              );
            }
            return <p key={i}>{b.text}</p>;
          })}
        </div>
        {event.photos && event.photos.length > 0 && (
          <PhotoGrid photos={event.photos} fit={event.fit} className="mt-10" />
        )}
      </div>
    </section>
  );
}
